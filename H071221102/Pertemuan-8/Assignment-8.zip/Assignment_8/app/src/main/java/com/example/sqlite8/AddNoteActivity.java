package com.example.sqlite8;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddNoteActivity extends AppCompatActivity {

    private EditText titleEditText, descriptionEditText;
    private Button submitButton;
    private DatabaseHelper db;
    private int noteId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        titleEditText = findViewById(R.id.titleEditText);
        descriptionEditText = findViewById(R.id.descriptionEditText);
        submitButton = findViewById(R.id.submitButton);
        db = new DatabaseHelper(this);

        if (getIntent().hasExtra("note_id")) {
            noteId = getIntent().getIntExtra("note_id", -1);
            loadNoteData(noteId);
            getSupportActionBar().setTitle("Update Note");
        } else {
            getSupportActionBar().setTitle("Create Note");
        }

        submitButton.setOnClickListener(v -> {
            String title = titleEditText.getText().toString();
            String description = descriptionEditText.getText().toString();

            if (title.isEmpty()) {
                Toast.makeText(this, "Please enter both title and description", Toast.LENGTH_SHORT).show();
            } else {
                if (noteId == -1) {
                    db.insertNote(title, description);
                    Toast.makeText(this, "Note created", Toast.LENGTH_SHORT).show();
                } else {
                    Note note = db.getNote(noteId);
                    note.setTitle(title);
                    note.setDescription(description);
                    db.updateNote(note);
                    Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
                }
                finish();
            }
        });

    }

    private void loadNoteData(int noteId) {
        Note note = db.getNote(noteId);
        titleEditText.setText(note.getTitle());
        descriptionEditText.setText(note.getDescription());
    }

    private String getCurrentDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        return sdf.format(new Date());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_update_delete, menu);
        if (noteId == -1) {
            MenuItem deleteItem = menu.findItem(R.id.action_delete);
            deleteItem.setVisible(false);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            showCancelConfirmationDialog();
            return true;
        } else if (item.getItemId() == R.id.action_delete) {
            showDeleteConfirmationDialog();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        showCancelConfirmationDialog();
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Apakah anda yakin ingin menghapusnya?")
                .setPositiveButton("Ya", (dialog, id) -> {
                    db.deleteNote(noteId);
                    Toast.makeText(AddNoteActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton("Tidak", (dialog, id) -> {
                    // User cancelled the dialog
                });
        builder.create().show();
    }

    private void showCancelConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Apakah anda ingin membatalkan penambahan atau perubahan pada form?")
                .setPositiveButton("Ya", (dialog, id) -> finish())
                .setNegativeButton("Tidak", (dialog, id) -> {
                    // User cancelled the dialog
                });
        builder.create().show();
    }
}