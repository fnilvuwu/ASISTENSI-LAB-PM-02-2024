package com.example.sharedpreference7;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView loginNIM, loginPassword;
    private Button btn_login, btn_register;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginNIM = findViewById(R.id.tv_nim);
        loginPassword = findViewById(R.id.tv_password);
        btn_login = findViewById(R.id.btn_login);
        btn_register = findViewById(R.id.btn_register);

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        boolean isDarkModeEnabled = sharedPreferences.getBoolean("isDarkModeEnabled", false);
        AppCompatDelegate.setDefaultNightMode(isDarkModeEnabled ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

        sharedPreferences = getSharedPreferences("registUser", MODE_PRIVATE);
        String nim = sharedPreferences.getString("NIM", "");
        String pass = sharedPreferences.getString("pass", "");
        SharedPreferences.Editor editor = sharedPreferences.edit();

        btn_login.setOnClickListener(v -> {
            if (loginNIM.getText().toString().trim().isEmpty()) {
                loginNIM.setError("Please fill this field");
                return;
            } if (loginPassword.getText().toString().trim().isEmpty()) {
                loginPassword.setError("Please fill this field");
                return;
            }
            String nimInput = loginNIM.getText().toString();
            String passInput = loginPassword.getText().toString();
            if (nimInput.equals(nim) && passInput.equals(pass)) {
                editor.putBoolean("isLoggedIn", true);
                editor.putString("NIM", nimInput);
                editor.apply();
                Intent intent = new Intent(this, LoginActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "NIM atau Password salah", Toast.LENGTH_SHORT).show();
            }
        });


        btn_register.setOnClickListener(v -> {
            Intent intent = new Intent(this, RegisterActivity.class);
            startActivity(intent);
            finish();
        });

        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        if (isLoggedIn) {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        }
    }
}