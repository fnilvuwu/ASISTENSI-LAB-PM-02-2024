package com.example.sharedpreference7;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class SaveTema {

    public static void saveThema(Context context, int temaMode){
        SharedPreferences sharedPreferences = context.getSharedPreferences("tema_shared", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("tema_mode", temaMode);
        editor.apply();
    }

    public static int getSaveThema(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("tema_shared", Context.MODE_PRIVATE);
        return sharedPreferences.getInt("tema_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
    }
}
