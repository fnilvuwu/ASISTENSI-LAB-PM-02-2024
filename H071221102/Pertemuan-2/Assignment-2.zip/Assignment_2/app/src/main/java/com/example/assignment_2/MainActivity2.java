package com.example.assignment_2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.assignment_2.MainActivity3;

public class MainActivity2 extends AppCompatActivity {

    EditText titleEditText, contentEditText;

    private String title;
    private String content;
    Button saveButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        titleEditText = findViewById(R.id.titleEditText);
        contentEditText = findViewById(R.id.contentEditText);
        saveButton = findViewById(R.id.saveButton);

        saveButton.setOnClickListener(v -> saveDataAndNavigate());

    }

    private void saveDataAndNavigate() {
        // Mengambil data dari EditText
        title = titleEditText.getText().toString();
        content = contentEditText.getText().toString();

        if (!title.isEmpty()  && !content.isEmpty()) {
            // Menyimpan data ke Intent untuk dikirim ke aktivitas berikutnya
            Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
            intent.putExtra("title", title);
            intent.putExtra("content", content);

            intent.putExtra("userInput", getIntent().getStringExtra("userInput"));
            intent.putExtra("usernameInput", getIntent().getStringExtra("usernameInput"));

            String imageUriString = getIntent().getStringExtra("imageUri");
            intent.putExtra("imageUri", imageUriString);


            // Menavigasi ke aktivitas berikutnya
            startActivity(intent);
        }

        else {
            Toast.makeText(this,"Lengkapi semua inputan", Toast.LENGTH_SHORT).show();
        }


    }
}
