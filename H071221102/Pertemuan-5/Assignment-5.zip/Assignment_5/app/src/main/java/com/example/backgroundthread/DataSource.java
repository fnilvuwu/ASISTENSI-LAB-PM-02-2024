package com.example.backgroundthread;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Account> accounts = generateDummyChats();

    private static ArrayList<Account> generateDummyChats() {
        ArrayList<Account> accounts = new ArrayList<>();
        accounts.add(new Account("Shin Tae Yong", "shintaeyong", R.drawable.sty_self, R.drawable.sty_team, "Go fight!"));
        accounts.add(new Account("Rafael Struick", "rafaelstruick", R.drawable.rafa_self, R.drawable.rafa_team, "What a team performance!"));
        accounts.add(new Account("Sandy Walsh", "sandywalsh", R.drawable.sandy_self, R.drawable.sandy_team, "Menyala Abangkuuu"));
        accounts.add(new Account("Arhan Pratama", "pratamaarhan", R.drawable.arhan_self, R.drawable.arhan_team, "Winning in life!"));
        accounts.add(new Account("Ernando Ari", "ernandoari", R.drawable.ernando_self, R.drawable.ernando_team, "Keep fight!"));
        accounts.add(new Account("Rizky Ridho", "rizkyridho", R.drawable.ridho_self, R.drawable.ridho_team, "My history"));
        return accounts;
    }
}
