package com.example.fragment;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Account> accounts = generateDummyChats();
    private static ArrayList<Account> generateDummyChats() {
        ArrayList<Account> accounts = new ArrayList<>();
        accounts.add(new Account("Rafael Struick", "rafaelstruick", "What a team performance!", R.drawable.rafa_self, R.drawable.rafa_team));
        accounts.add(new Account("Asnawi Mangkualam", "asnawimangkualam", "The journey continues..", R.drawable.asnawi_self, R.drawable.asnawi_team));
        accounts.add(new Account("Arhan Pratama", "pratamaarhan", "Winning in life!", R.drawable.arhan_self, R.drawable.arhan_team));
        accounts.add(new Account("Justin Hubner", "justin_hubner", "Proud of all them wrong", R.drawable.hubner_self, R.drawable.hubner_team));
        accounts.add(new Account("Sandy Walsh", "sandywalsh", "Menyala abangkuhhh", R.drawable.sandy_self, R.drawable.sandy_team));
        return accounts;
    }
}
