package com.example.networking6;

import java.util.List;

public class DataResponse {

    private List<Data> data;
    public List<Data> getData() {
        return data;
    }
    public void setData(List<Data> data) {
        this.data = data;
    }

}
