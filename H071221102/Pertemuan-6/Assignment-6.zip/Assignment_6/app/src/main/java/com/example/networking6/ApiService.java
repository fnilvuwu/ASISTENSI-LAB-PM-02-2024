package com.example.networking6;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    @GET("api/users")
    Call<DataResponse> getUsers(@Query("per_page") int page);

    @GET("api/users/{id}")
    Call<DataResponse> getUserById(@Path("id") int userId);

}
