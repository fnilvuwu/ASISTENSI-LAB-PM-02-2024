package com.example.assignment_3;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Account> accounts = generateDummyChats();
    private static ArrayList<Account> generateDummyChats(){
        ArrayList<Account> accounts = new ArrayList<>();
        accounts.add(new Account(R.drawable.sty_self, R.drawable.sty_team, R.drawable.sty_story ,"shintaeyong", "2,5jt", "812", "Home match with Vietnam~"));
        accounts.add(new Account(R.drawable.ernando_self, R.drawable.ernando_team, R.drawable.ernando_story ,"ernandoari", "1,5jt", "800", "good memory"));
        accounts.add(new Account(R.drawable.ridho_self, R.drawable.ridho_team, R.drawable.ridho_story, "rizkyridho", "999", "205", "Nek wes rezekine ora bakal ketukar"));
        accounts.add(new Account(R.drawable.hubner_self, R.drawable.hubner_team, R.drawable.justin_story, "justinhubner", "1,1jt", "328", "Proud of all them wrong"));
        accounts.add(new Account(R.drawable.sandy_self, R.drawable.sandy_team, R.drawable.sandy_story,"sandywalsh", "1,5jt", "912", "Menyala abangkuhhh"));
        accounts.add(new Account(R.drawable.arhan_self, R.drawable.arhan_team, R.drawable.arhan_story, "arhanpratama", "3,6jt", "415", "Winning in life!"));
        accounts.add(new Account(R.drawable.asnawi_self, R.drawable.asnawi_team, R.drawable.asnawi_story, "asnawimangkualam", "2,1jt", "358", "The journey continues.."));
        accounts.add(new Account(R.drawable.ivar_self, R.drawable.ivar_team, R.drawable.ivar_story, "ivarjenner", "1,8jt", "855", "Proud of the team"));
        accounts.add(new Account(R.drawable.lino_self, R.drawable.lino_team, R.drawable.lino_story, "marselinoferdinand", "2,2jt", "656", "Passion"));
        accounts.add(new Account(R.drawable.rafa_self, R.drawable.rafa_team, R.drawable.rafa_story, "rafaelstruick", "1,3jt", "525", "What a team performance! +3\n" +
                "And thank you for all the kind messages"));
        return accounts;
    }


}