package com.example.pertemuan3;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<ProfileModel> profiles = generateDummyProfiles();


    private static ArrayList<ProfileModel> generateDummyProfiles() {
        ArrayList<ProfileModel> profiles = new ArrayList<>();
        profiles.add(new ProfileModel("Deadal", R.drawable.alqa, R.drawable.al1, "129JT", "122", "Al Qadri", "Hello, I'm Developer Aplikasi.", R.drawable.al, "ini Postingan Alqa"));
        profiles.add(new ProfileModel("Rimuru", R.drawable.rr, R.drawable.rr1, "1950", "1299", "Rimuru Tempest", "Hello, I'm Penguasa Tempest.", R.drawable.rr,"ini Postingan Tempest"));
        profiles.add(new ProfileModel("Ayanokojii", R.drawable.cr, R.drawable.cr1, "1,002", "388", "Ayanokoji Kiyotaka", "Hello, I'm Ayanokoji.", R.drawable.cr,"ini Anime Classroom Of the Elite"));
        profiles.add(new ProfileModel("Luffy", R.drawable.al1, R.drawable.al, "21,444", "2540", "Monkey D. Luffy", "Hello, I'm Raja Bajak Laut.", R.drawable.al1,"ini Instagram Raja Bajak Laut"));
        profiles.add(new ProfileModel("Senku", R.drawable.dr, R.drawable.dr1, "3901", "3205", "Senku Ishigami", "Hello, I'm Dr.Stone.", R.drawable.dr,"ini Instagram Dunia Pembatuan"));
        profiles.add(new ProfileModel("Hinata", R.drawable.hn, R.drawable.hn1, "1785", "1555", "Hinata Shoyo", "Hello I like Volley Ball.", R.drawable.hn,"ini Raja Volli"));
        profiles.add(new ProfileModel("Kuroko", R.drawable.kr, R.drawable.kr1, "18,000", "1812", "Tetsuya Kuroko", "Hello,  I'm member 6 keajaiban.", R.drawable.kr,"ini raja basket"));
        profiles.add(new ProfileModel("Jing-Woo", R.drawable.sl, R.drawable.sl1, "52456", "2200", "Sung Jing-Wo", "Hello, I'm Raja Kegelapan.", R.drawable.sl,"ini raja monarch"));
        profiles.add(new ProfileModel("Saitama", R.drawable.foto, R.drawable.opm, "744", "124", "Saitama Botak", "Hello, I'm Saitama.", R.drawable.foto,"ini Raja satu pukulan"));
        profiles.add(new ProfileModel("Naruto", R.drawable.nar, R.drawable.nar1, "1", "2", "Uzumaki Naruto", "Hello, I'm Kyubi.", R.drawable.nar,"ini Kyubiii ekor 9"));
        return profiles;
    }
}