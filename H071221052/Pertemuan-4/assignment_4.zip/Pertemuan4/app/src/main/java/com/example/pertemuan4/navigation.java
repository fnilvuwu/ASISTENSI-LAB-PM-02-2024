package com.example.pertemuan4;

import android.app.Activity;

public class navigation extends Activity {
}

//Tadinya mau buat di sini untuk aktifitas navigationnya tapi saya buat di mainactivity saja kak, karena kosongji juga
