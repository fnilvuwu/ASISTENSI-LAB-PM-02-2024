package com.example.myapplication;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Uri image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = findViewById(R.id.gambar);
        EditText editText = findViewById(R.id.nama);
        EditText editText2 = findViewById(R.id.username);
        Button buttonSubmit = findViewById(R.id.btn_nama);

        ActivityResultLauncher<Intent> launcherIntentGallery = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        image = data.getData();
                        imageView.setImageURI(image);
                    }
                }
        );

        imageView.setOnClickListener(view -> {
            Intent openGallery = new Intent(Intent.ACTION_PICK); // memilih sesuatu (dalam hal ini, gambar).
            openGallery.setType("image/*"); //menunjukkan bahwa kita hanya ingin pengguna memilih file gambar (apa pun formatnya seperti jpg, png, dll.
            launcherIntentGallery.launch(openGallery);
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editText.getText().toString().trim();
                String username = editText2.getText().toString().trim();
                boolean isImageProvided = image != null; // isImageProvided menjadi true jika gambar tersedia, dan false jika tidak.

                if (name.isEmpty() || username.isEmpty() || !isImageProvided) {
                    Toast.makeText(MainActivity.this, "Harap isi semua kolom dan upload gambar", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    intent.putExtra("name", name);
                    intent.putExtra("username", username);
                    if (isImageProvided) {
                        intent.putExtra("image", image.toString()); //Jika gambar tersedia, menambahkan informasi gambar (URI-nya) ke dalam Intent
                    }
                    startActivity(intent);
                }
            }
        });
            //menambahkan data ke dalam objek Intent. Data ini dapat berupa nilai primitif (seperti String, int, boolean) atau objek Parcelable.
    }
}