package com.example.assignment_1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editTextUsername;
    Button buttonSave;
    TextView textViewResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextUsername = findViewById(R.id.inputLainnya);
        buttonSave = findViewById(R.id.buttonOk);
        textViewResult = findViewById(R.id.isiLainnya);

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = editTextUsername.getText().toString();

                if (!TextUtils.isEmpty(username)){
                    String existingText = textViewResult.getText().toString();
                    if(!TextUtils.isEmpty(existingText)){
                        existingText += "\n";
                    }
                    String newText = existingText + username;
                    textViewResult.setText(newText);
                    textViewResult.setVisibility(View.VISIBLE);
                    editTextUsername.setText("");
                }
            }
        });
    }
}
