package com.example.assignment_4.fragment;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assignment_4.DataSource;
import com.example.assignment_4.R;
import com.example.assignment_4.AccountAdapter;

public class HomeFragment extends Fragment {

    private RecyclerView rv_users;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        rv_users = view.findViewById(R.id.rv_users);

        rv_users.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        rv_users.setHasFixedSize(true);
        AccountAdapter userAdapter = new AccountAdapter(DataSource.accounts);
        rv_users.setAdapter(userAdapter);
        return view;

    }
}