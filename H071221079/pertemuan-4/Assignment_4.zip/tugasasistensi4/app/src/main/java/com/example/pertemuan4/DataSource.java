package com.example.pertemuan4;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new Instagram("Ghast","SoulflameSpecter"
                ,"Angkatlah suaramu, walaupun di tengah keheningan yang dalam. Biarkan api semangatmu menyala di dalam hatimu."
                ,R.drawable.ghost,R.drawable.ghost));

        instagrams1.add(new Instagram("Creeper", "PhantomBomber"
                ,"Jangan biarkan masa lalu meledakkan masa depanmu. Bangunlah dengan keberanian dan hati yang baru."
                ,R.drawable.creeper,R.drawable.creeper));

        instagrams1.add(new Instagram("Skeleton", "GrimReaperArrow"
                ,"Tulang-tulangku mungkin kering, tetapi semangatku tetap kuat. Teruslah berjalan, meski jalannya berbatu."
                ,R.drawable.skeleton, R.drawable.skeleton));

        instagrams1.add((new Instagram("Enderman","DimensionalSpecter"
                ,"Di dalam kesunyian, temukanlah kekuatanmu yang sejati. Kembangkanlah dirimu di tengah ketidakpastian."
                ,R.drawable.enderman,R.drawable.enderman)));

        instagrams1.add(new Instagram("Zombie", "DeathEaterAlpha"
                ,"Jangan biarkan kelemahanmu menentukan nasibmu. Bangkitlah setiap kali jatuh, dan berjalanlah menuju cahaya."
                ,R.drawable.zombie,R.drawable.zombie));

        instagrams1.add(new Instagram("Zombie Pigman","PyroSwineOverlord"
                ,"Maafkan masa lalu, dan temukanlah kedamaianmu di tengah kekacauan. Biarkan kebijaksanaanmu membimbing langkahmu."
                ,R.drawable.zombiepigman, R.drawable.zombiepigman));

        instagrams1.add(new Instagram("Wither Skeleton","GrimDarkShadow"
                , "Di dalam kehancuran, temukanlah kekuatan untuk bangkit. Jadilah seperti tulang yang kuat, menantang badai dengan keteguhan."
                ,R.drawable.witherskeleton,R.drawable.witherskeleton));

        instagrams1.add(new Instagram("Slime","ViscousVortexKing"
                ,"Fleksibilitasmu adalah kekuatanmu yang sejati. Biarkan dirimu berkembang tanpa batas, seperti slime yang tak terbatas."
                ,R.drawable.slime, R.drawable.slime));

        instagrams1.add(new Instagram("Spider", "WebSlingerAssassin"
                ,"Rajutlah jaring kehidupanmu dengan teliti dan penuh perhitungan. Biarkan setiap langkahmu menjadi langkah yang kuat."
                ,R.drawable.spider, R.drawable.spider));

        instagrams1.add(new Instagram("Ender Dragon", "DraconicRiftMaster"
                ,"Terbanglah tinggi di atas langit, dan taklukkan tantangan yang menghadang. Jadilah seperti naga, memancarkan kebebasan dan keberanian."
                ,R.drawable.enderdragon, R.drawable.enderdragon));
        return instagrams1;
    }
}
