package com.example.asistensipekan3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PostinganActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postingan);

        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);


        TextView namapost = findViewById(R.id.namapost);
        TextView namapostlagi = findViewById(R.id.namapostlagi);
        TextView bionya = findViewById(R.id.bionya);

        ImageView ppost = findViewById(R.id.ppost);
        ImageView postpost = findViewById(R.id.postpost);

        namapost.setText(nama);
        namapostlagi.setText(nama);
        bionya.setText(bio);
        ppost.setImageResource(pp);
        postpost.setImageResource(postnya);

    }

    public void kepropil(View view) {
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);

        Intent balikpropil = new Intent(PostinganActivity.this, ProfileActivity.class);
        balikpropil.putExtra("nama", nama);
        balikpropil.putExtra("follower", follower);
        balikpropil.putExtra("following", following);
        balikpropil.putExtra("bio", bio);
        balikpropil.putExtra("pp", pp);
        balikpropil.putExtra("postnya", postnya);
        balikpropil.putExtra("storynya", storynya);

        startActivity(balikpropil);
    }

    public void storyeh(View view) {
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);

        Intent storylagiges = new Intent(PostinganActivity.this, StoryActivity.class);
        storylagiges.putExtra("nama", nama);
        storylagiges.putExtra("follower", follower);
        storylagiges.putExtra("following", following);
        storylagiges.putExtra("bio", bio);
        storylagiges.putExtra("pp", pp);
        storylagiges.putExtra("postnya", postnya);
        storylagiges.putExtra("storynya", storynya);

        startActivity(storylagiges);
    }
}