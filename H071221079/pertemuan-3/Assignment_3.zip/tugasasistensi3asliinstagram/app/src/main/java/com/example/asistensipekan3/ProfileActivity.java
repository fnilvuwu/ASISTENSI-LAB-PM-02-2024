package com.example.asistensipekan3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);


        TextView namapropil = findViewById(R.id.namaprofilenyaprofil);
        TextView follownya = findViewById(R.id.followerprofil);
        TextView followingnya = findViewById(R.id.followingprofil);

        ImageView potopropil = findViewById(R.id.ppprofile);
        ImageView postpropil = findViewById(R.id.postprofile);

        namapropil.setText(nama);
        follownya.setText(follower);
        followingnya.setText(following);
        potopropil.setImageResource(pp);
        postpropil.setImageResource(postnya);
    }

    public void gaskanlagi(View view) {
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);

        Intent golagi = new Intent(ProfileActivity.this, StoryActivity.class);
        golagi.putExtra("nama", nama);
        golagi.putExtra("follower", follower);
        golagi.putExtra("following", following);
        golagi.putExtra("bio", bio);
        golagi.putExtra("pp", pp);
        golagi.putExtra("postnya", postnya);
        golagi.putExtra("storynya", storynya);

        startActivity(golagi);
    }

    public void gaspost(View view) {
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);

        Intent kepost = new Intent(ProfileActivity.this, PostinganActivity.class);
        kepost.putExtra("nama", nama);
        kepost.putExtra("follower", follower);
        kepost.putExtra("following", following);
        kepost.putExtra("bio", bio);
        kepost.putExtra("pp", pp);
        kepost.putExtra("postnya", postnya);
        kepost.putExtra("storynya", storynya);

        startActivity(kepost);
    }
}