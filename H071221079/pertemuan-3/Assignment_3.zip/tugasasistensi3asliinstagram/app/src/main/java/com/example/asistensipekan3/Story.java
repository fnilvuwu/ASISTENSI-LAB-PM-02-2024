package com.example.asistensipekan3;


import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Story implements Parcelable {
    private Integer profile;
    private String user;
    private Integer post;
    private String user2;
    private String caption;
    private String follower;
    private String following;

    public String getFollower() {
        return follower;
    }

    public void setFollower(String follower) {
        this.follower = follower;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }


    public Integer getProfile() {
        return profile;
    }

    public void setProfile(Integer profile) {
        this.profile = profile;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Integer getPost() {
        return post;
    }

    public void setPost(Integer post) {
        this.post = post;
    }

    public String getUser2() {
        return user2;
    }

    public void setUser2(String user2) {
        this.user2 = user2;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public Story(Integer profile, String user, Integer post, String user2, String caption, String follower, String following) {
        this.profile = profile;
        this.user = user;
        this.post = post;
        this.user2 = user2;
        this.caption = caption;
        this.follower = follower;
        this.following = following;


    }

    protected Story(Parcel in) {
        if (in.readByte() == 0) {
            profile = null;
        } else {
            profile = in.readInt();
        }

        if (in.readByte() == 0) {
            post = null;
        } else {
            post = in.readInt();
        }


        user = in.readString();
        user2 = in.readString();
        caption = in.readString();
        follower = in.readString();
        following = in.readString();

    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (profile == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(profile);
        }

        if (post == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(post);
        }


        dest.writeString(user);
        dest.writeString(user2);
        dest.writeString(caption);
        dest.writeString(follower);
        dest.writeString(following);

    }


    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Story> CREATOR = new Creator<Story>() {
        @Override
        public Story createFromParcel(Parcel in) {
            return new Story(in);
        }

        @Override
        public Story[] newArray(int size) {
            return new Story[size];
        }
    };


}
