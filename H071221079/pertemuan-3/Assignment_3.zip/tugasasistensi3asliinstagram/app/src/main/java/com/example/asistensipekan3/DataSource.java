package com.example.asistensipekan3;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Story> storys = generateDummyStorys();

    private static ArrayList<Story> generateDummyStorys() {
        ArrayList<Story> storys = new ArrayList<>();
        storys.add(new Story(R.drawable.ml, "Mobile Legend", R.drawable.mlpost, "Mobile Legend", "WELKOM TU MOBELEJENG PAIP SEKONS TU BI ENEMI RIC DE BETELPIELD", "123", "234"));
        storys.add(new Story(R.drawable.ff, "Free Fire", R.drawable.ffpost, "Free Fire", "SURGA ITU EPEP SURGA ITU EPEP", "412", "523"));
        storys.add(new Story(R.drawable.pubg, "PUBG", R.drawable.pubgpost, "PUBG", "DBS HARAM", "433", "123"));
        storys.add(new Story(R.drawable.gi, "Genshin Impact", R.drawable.gipost, "Genshin Impact", "KAPAN ZHONGLI RERUN WOE", "733", "122"));
        storys.add(new Story(R.drawable.mc, "Minecraft", R.drawable.mcpost, "Minecraft", "TUTOR MLG WATER BAKET PECE", "524", "112"));
        storys.add(new Story(R.drawable.hsr, "Honkai Star", R.drawable.hsrpost, "Honkai Star", "GEM MAYAD", "642", "122"));
        storys.add(new Story(R.drawable.coc, "Clash Of Clans", R.drawable.cocpost, "Clash Of Clans", "TEREDEN TENTEN TEN TENTENTENTEN", "533", "122"));
        storys.add(new Story(R.drawable.codm, "Call Of Duty", R.drawable.codmpost, "Call Of Duty", "TUTOR SLEDING JAMSUT", "611", "122"));
        storys.add(new Story(R.drawable.ojol, "Ojol", R.drawable.ojolpost, "Ojol", "APA INI BJIR", "622", "122"));
        storys.add(new Story(R.drawable.aov, "Arena Of Valor", R.drawable.aovpost, "Arena Of Valor", "BOSAN", "612", "155"));

        return storys;
    }

    public static ArrayList<Post> posts = generateDummyPosts();

    private static ArrayList<Post> generateDummyPosts() {
        ArrayList<Post> posts = new ArrayList<>();
        posts.add(new Post(R.drawable.ml, "Mobile Legend", R.drawable.mlpost, "Mobile Legend", "WELKOM TU MOBELEJENG PAIP SEKONS TU BI ENEMI RIC DE BETELPIELD", "123", "234"));
        posts.add(new Post(R.drawable.ff, "Free Fire", R.drawable.ffpost, "Free Fire", "SURGA ITU EPEP SURGA ITU EPEP", "133", "734"));
        posts.add(new Post(R.drawable.pubg, "PUBG", R.drawable.pubgpost, "PUBG", "DBS HARAM", "623", "334"));
        posts.add(new Post(R.drawable.gi, "Genshin Impact", R.drawable.gipost, "Genshin Impact", "KAPAN ZHONGLI RERUN WOE", "723", "293"));
        posts.add(new Post(R.drawable.mc, "Minecraft", R.drawable.mcpost, "Minecraft", "TUTOR MLG WATER BAKET PECE", "123", "414"));
        posts.add(new Post(R.drawable.hsr, "Honkai Star", R.drawable.hsrpost, "Honkai Star", "GEM MAYAD", "123", "534"));
        posts.add(new Post(R.drawable.coc, "Clash Of Clans", R.drawable.cocpost, "Clash Of Clans", "TEREDEN TENTEN TEN TENTENTENTEN", "123", "754"));
        posts.add(new Post(R.drawable.codm, "Call Of Duty", R.drawable.codmpost, "Call Of Duty", "TUTOR SLEDING JAMSUT", "233", "434"));
        posts.add(new Post(R.drawable.ojol, "Ojol", R.drawable.ojolpost, "Ojol", "APA INI BJIR", "923", "534"));
        posts.add(new Post(R.drawable.aov, "Arena Of Valor", R.drawable.aovpost, "Arena Of Valor", "BOSAN", "173", "634"));

        return posts;
    }

}




