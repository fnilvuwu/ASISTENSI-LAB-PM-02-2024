package com.example.asistensipekan3;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder> {

    private final ArrayList<Story> storys;

    public StoryAdapter(ArrayList<Story> storys) {
        this.storys = storys;
    }

    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Story story = storys.get(position);
        holder.setData(story);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Membuat Intent dan menambahkan data story
                Intent intent = new Intent(v.getContext(), StoryActivity.class);
                intent.putExtra("nama", story.getUser());
                intent.putExtra("pp", story.getProfile());
                intent.putExtra("storynya", story.getPost());
                intent.putExtra("follower", story.getFollower());
                intent.putExtra("following", story.getFollowing());
                intent.putExtra("postnya", story.getPost());
                intent.putExtra("bio", story.getCaption());


                v.getContext().startActivity(intent);
            }
        });


    }


    @Override
    public int getItemCount() {
        return storys.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView ivProfile;
        private final TextView tvUser;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProfile = itemView.findViewById(R.id.iv_profile);
            tvUser = itemView.findViewById(R.id.tv_user_profile);

        }

        public void setData(Story story) {
            ivProfile.setImageResource(story.getProfile());
            tvUser.setText(story.getUser());


        }
    }
}
