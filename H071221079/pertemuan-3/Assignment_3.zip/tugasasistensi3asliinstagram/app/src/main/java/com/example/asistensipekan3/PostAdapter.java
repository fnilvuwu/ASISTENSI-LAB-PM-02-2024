package com.example.asistensipekan3;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {

    private final ArrayList<Post> posts;

    public PostAdapter(ArrayList<Post> posts) {
        this.posts = posts;
    }

    @NonNull
    @Override
    public PostAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post, parent, false);
        return new PostAdapter.ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull PostAdapter.ViewHolder holder, int position) {
        Post post = posts.get(position);
        holder.setData(post);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(v.getContext(), ProfileActivity.class);
                intent.putExtra("nama", post.getUser());
                intent.putExtra("pp", post.getProfile());
                intent.putExtra("storynya", post.getPost());
                intent.putExtra("follower", post.getFollower());
                intent.putExtra("following", post.getFollowing());
                intent.putExtra("postnya", post.getPost());
                intent.putExtra("bio", post.getCaption());


                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return posts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final ImageView ivProfile;
        private final TextView tvUser;
        private final ImageView ivPost;
        private final TextView tvUser2;
        private final TextView tvCaption;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProfile = itemView.findViewById(R.id.iv_profile);
            tvUser = itemView.findViewById(R.id.tv_user_profile);
            ivPost = itemView.findViewById(R.id.iv_image_post);
            tvUser2 = itemView.findViewById(R.id.tv_user_profile2);
            tvCaption = itemView.findViewById(R.id.tv_caption);

        }

        public void setData(Post post) {
            ivProfile.setImageResource(post.getProfile());
            tvUser.setText(post.getUser());
            ivPost.setImageResource(post.getPost());
            tvUser2.setText(post.getUser2());
            tvCaption.setText(post.getCaption());

        }
    }
}