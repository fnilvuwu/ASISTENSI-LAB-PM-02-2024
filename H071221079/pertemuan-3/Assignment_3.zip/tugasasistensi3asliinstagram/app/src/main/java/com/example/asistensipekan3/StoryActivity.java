package com.example.asistensipekan3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class StoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story);

        Intent intent = getIntent();

        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);


        TextView name = findViewById(R.id.story_nama);
        ImageView propil = findViewById(R.id.story_pp);
        ImageView poststory = findViewById(R.id.story_gambar);

        name.setText(nama);
        propil.setImageResource(pp);
        poststory.setImageResource(storynya);


    }

    public void gaskan(View view) {
        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String follower = intent.getStringExtra("follower");
        String following = intent.getStringExtra("following");
        String bio = intent.getStringExtra("bio");
        int pp = intent.getIntExtra("pp", 0);
        int postnya = intent.getIntExtra("postnya", 0);
        int storynya = intent.getIntExtra("storynya", 0);

        Intent go = new Intent(StoryActivity.this, ProfileActivity.class);
        go.putExtra("nama", nama);
        go.putExtra("follower", follower);
        go.putExtra("following", following);
        go.putExtra("bio", bio);
        go.putExtra("pp", pp);
        go.putExtra("postnya", postnya);
        go.putExtra("storynya", storynya);

        startActivity(go);
    }
}