package com.example.asistensipekan3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        RecyclerView rvStory = findViewById(R.id.rv_story);
        rvStory.setHasFixedSize(true);

        RecyclerView rvPosts = findViewById(R.id.rv_posts);
        rvPosts.setHasFixedSize(true);

        StoryAdapter storyAdapter = new StoryAdapter(DataSource.storys);
        rvStory.setAdapter(storyAdapter);

        PostAdapter postAdapter = new PostAdapter(DataSource.posts);
        rvPosts.setAdapter(postAdapter);
    }
}