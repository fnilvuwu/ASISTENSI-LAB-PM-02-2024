package com.example.tugasasistensi2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_IMAGE = 1;
    private ImageView imageView;
    private EditText editTextName;
    private EditText editTextAge;

    private Uri selectedImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        editTextName = findViewById(R.id.editTextName);
        editTextAge = findViewById(R.id.editTextAge);
        imageView.setImageResource(R.drawable.baseline_camera_alt_24);
    }

    public void selectImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_IMAGE);
    }

    public void kedua(View view) {
        boolean isNameFilled = isNameFilled();
        boolean isAgeFilled = isAgeFilled();

        if (isNameFilled && isAgeFilled) {
            if (isImageSelected()) {
                Intent pindah = new Intent(MainActivity.this, MainActivity2.class);

                pindah.putExtra("imageUri", selectedImageUri.toString());
                pindah.putExtra("name", editTextName.getText().toString());
                pindah.putExtra("username", editTextAge.getText().toString());

                startActivity(pindah);
            } else {
                Toast.makeText(this, "Isi Gambar sod", Toast.LENGTH_SHORT).show();
            }
        } else {

            if (!isNameFilled) {
                editTextName.setError("Nama harus diisi");
            }
            if (!isAgeFilled) {
                editTextAge.setError("Username harus diisi");
            }
        }
    }


    private boolean isImageSelected() {
        return selectedImageUri != null;
    }

    private boolean isNameFilled() {
        return !TextUtils.isEmpty(editTextName.getText().toString().trim());
    }

    private boolean isAgeFilled() {
        return !TextUtils.isEmpty(editTextAge.getText().toString().trim());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
            imageView.setImageURI(selectedImageUri);
        }
    }
}
