package com.example.tugasasistensi2;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;


public class MainActivity3 extends AppCompatActivity {
    private ImageView imageView;
    private TextView name;
    private TextView username;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        imageView = findViewById(R.id.imageView);
        name = findViewById(R.id.name);
        username = findViewById(R.id.username);

        TextView noteatascuy = findViewById(R.id.noteatascuy);
        TextView notebawahcuy = findViewById(R.id.notebawahcuy);
        noteatascuy.setText(getIntent().getStringExtra("noteatas"));
        notebawahcuy.setText(getIntent().getStringExtra("notebawah"));


        String imageUri = getIntent().getStringExtra("imageUri");
        if (imageUri != null) {
            imageView.setImageURI(Uri.parse(imageUri));
        }
        name.setText(getIntent().getStringExtra("name"));
        username.setText(getIntent().getStringExtra("username"));

    }
}