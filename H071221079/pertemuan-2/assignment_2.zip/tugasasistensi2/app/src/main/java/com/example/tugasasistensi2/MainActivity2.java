package com.example.tugasasistensi2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    private EditText editnoteatas;
    private EditText editnotebawah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editnoteatas = findViewById(R.id.editnoteatas);
        editnotebawah = findViewById(R.id.editnotebawah);
    }

    public void ketiga(View view) {
        String noteAtas = editnoteatas.getText().toString().trim();
        String noteBawah = editnotebawah.getText().toString().trim();

        if (TextUtils.isEmpty(noteAtas) || TextUtils.isEmpty(noteBawah)) {
            Toast.makeText(this, "Mohon lengkapi semua catatan terlebih dahulu", Toast.LENGTH_SHORT).show();
        } else {
            Intent intent = getIntent();
            if (intent != null) {
                String imageUri = intent.getStringExtra("imageUri");
                String name = intent.getStringExtra("name");
                String username = intent.getStringExtra("username");

                Intent pergiketiga = new Intent(MainActivity2.this, MainActivity3.class);
                pergiketiga.putExtra("imageUri", imageUri);
                pergiketiga.putExtra("name", name);
                pergiketiga.putExtra("username", username);

                pergiketiga.putExtra("noteatas", noteAtas);
                pergiketiga.putExtra("notebawah", noteBawah);

                startActivity(pergiketiga);
            }
        }
    }
}
