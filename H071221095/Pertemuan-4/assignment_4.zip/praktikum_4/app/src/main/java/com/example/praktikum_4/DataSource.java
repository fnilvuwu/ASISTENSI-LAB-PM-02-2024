package com.example.praktikum_4;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new Instagram("makeoverid","Make Over Indonesia"
                ,"Powerstay 24H Matte Powder Foundation"
                ,R.drawable.makeov,R.drawable.postmake));

        instagrams1.add(new Instagram("focallureid", "Focallure Indonesia"
                ,"Beautiful lip wraps for your lips with colors that are suitable for various skin tones"
                ,R.drawable.foc,R.drawable.postfoc));

        instagrams1.add(new Instagram("esqabeauty", "E S Q A"
                ,"Ready to be the talk of the town?"
                ,R.drawable.esqa, R.drawable.postesqa));

        instagrams1.add((new Instagram("rarebeauty","Rare Beauty by Selena Gomez"
                ,"Fill in the blank: I find comfort in...... (Drop your answer in the comments)"
                ,R.drawable.rare,R.drawable.postrare)));

        instagrams1.add(new Instagram("barenbliss", "Barenbliss Indonesia"
                ,"From 4 to 14 shades, your love has made it all possible!"
                ,R.drawable.bnb,R.drawable.postbnb));

        instagrams1.add(new Instagram("skintific","Skintific Indonesia"
                ,"Tips got a flawless look for New Year's Eve"
                ,R.drawable.skintific, R.drawable.postskin));

        instagrams1.add(new Instagram("luxcrime_id","Luxcrime Cosmetics & Beauty"
                , "Upgrade your makeup game with Blur & Cover Two Way Cake's new version"
                ,R.drawable.luxcrime,R.drawable.postluxc));

        instagrams1.add(new Instagram("eminabeauty","Emina Cosmetics"
                ,"Your Comfy Bestie has arrived! Introducing, the NEW CREAMATTE"
                ,R.drawable.emina, R.drawable.postemina));

        instagrams1.add(new Instagram("somethincid", "SOMETHINC"
                ,"Which moisturizer is your match?"
                ,R.drawable.somethinc, R.drawable.postsome));

        instagrams1.add(new Instagram("mop.beauty", "MotherOfPearl by Tasya Farasya"
                ,"Our daily makeup power: Microblur Translucent Loose Pewder"
                ,R.drawable.mop, R.drawable.postmop));
        return instagrams1;
    }
}

