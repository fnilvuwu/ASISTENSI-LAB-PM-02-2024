package com.example.praktikum_4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.widget.ImageView;

import com.example.praktikum_4.fragment.HomeFragment;
import com.example.praktikum_4.fragment.PostinganFragment;
import com.example.praktikum_4.fragment.ProfileFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView iv_posting = findViewById(R.id.IV_Post);
        ImageView iv_profile = findViewById(R.id.IV_Profile);
        ImageView IV_Home = findViewById(R.id.IV_Home);

        FragmentManager fragmentManager = getSupportFragmentManager(); //mengelola bagaimana fragmen ditambahkan, dihapus, atau diganti di laya

        HomeFragment homeFragment = new HomeFragment();//menambahkan fragment ke layar home

        Fragment fragment = fragmentManager.findFragmentByTag(HomeFragment.class.getSimpleName());//mencari fragment dengan nama yg sesuai

        //mengecek fragment dan menambahkan jika belum ada
        if (!(fragment instanceof HomeFragment)){
            fragmentManager
                    .beginTransaction().add(R.id.frame_container, homeFragment)
                    .commit();
        }

        iv_posting.setOnClickListener(v -> {
            PostinganFragment postinganFragment = new PostinganFragment();
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.frame_container, postinganFragment)
                    .addToBackStack(null)
                    .commit();
        });

        iv_profile.setOnClickListener(v -> {
            ProfileFragment profileFragment = new ProfileFragment();
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.frame_container, profileFragment)
                    .addToBackStack(null)
                    .commit();
        });

        IV_Home.setOnClickListener(v -> {
            fragmentManager
                    .beginTransaction()
                    .replace(R.id.frame_container, homeFragment)
                    .addToBackStack(null)
                    .commit();
        });

    }
}