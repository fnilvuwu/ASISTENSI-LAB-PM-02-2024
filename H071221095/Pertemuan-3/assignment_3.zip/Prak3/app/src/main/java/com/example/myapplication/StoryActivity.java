package com.example.myapplication;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class StoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story);

        ImageView ivProfile = findViewById(R.id.iv_profile2);
        TextView tvProfile = findViewById(R.id.tv_profile2);
        ImageView imageStory = findViewById(R.id.imageStory);

        Intent intent = getIntent();

        int fotoProfile = intent.getIntExtra("FOTO PROFILE",0);
        String namaProfile = intent.getStringExtra("NAMA PROFILE");
        int fotoStory = intent.getIntExtra("STORY", 0);

        ivProfile.setImageResource(fotoProfile);
        tvProfile.setText(namaProfile);
        imageStory.setImageResource(fotoStory);

        tvProfile.setOnClickListener(v -> {
            // Check condition based on profile name
            if (namaProfile.equals("barenbliss_id")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.bnb);
                profileIntent.putExtra("NAMA PROFILE", "barenbliss_id");
                profileIntent.putExtra("FOLLOWERS", "185K");
                profileIntent.putExtra("FOLLOWING","13");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postbnb);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("rarebeauty")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.rare);
                profileIntent.putExtra("NAMA PROFILE", "rarebeauty");
                profileIntent.putExtra("FOLLOWERS", "7,2M");
                profileIntent.putExtra("FOLLOWING","353");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postrare);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("luxcrime_id")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.luxcrime);
                profileIntent.putExtra("NAMA PROFILE", "luxcrime_id");
                profileIntent.putExtra("FOLLOWERS", "680K");
                profileIntent.putExtra("FOLLOWING","225");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postluxc);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("makeoverid")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.makeov);
                profileIntent.putExtra("NAMA PROFILE", "makeoverid");
                profileIntent.putExtra("FOLLOWERS", "1,3M");
                profileIntent.putExtra("FOLLOWING","174");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postmake);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("somethincofficial")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.somethinc);
                profileIntent.putExtra("NAMA PROFILE", "somethincofficial");
                profileIntent.putExtra("FOLLOWERS", "1,4M");
                profileIntent.putExtra("FOLLOWING","2.093");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postsome);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("esqacosmetics")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.esqa);
                profileIntent.putExtra("NAMA PROFILE", "esqacosmetics");
                profileIntent.putExtra("FOLLOWERS", "295K");
                profileIntent.putExtra("FOLLOWING","14");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postesqa);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("skintificid")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.skintific);
                profileIntent.putExtra("NAMA PROFILE", "skintificid");
                profileIntent.putExtra("FOLLOWERS", "829K");
                profileIntent.putExtra("FOLLOWING","67");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postskin);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("mop.beauty")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.mop);
                profileIntent.putExtra("NAMA PROFILE", "mop.beauty");
                profileIntent.putExtra("FOLLOWERS", "387K");
                profileIntent.putExtra("FOLLOWING","1");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postmop);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("focallurebeauty")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.foc);
                profileIntent.putExtra("NAMA PROFILE", "focallurebeauty");
                profileIntent.putExtra("FOLLOWERS", "279K");
                profileIntent.putExtra("FOLLOWING","270");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postfoc);
                startActivity(profileIntent);
            }
            if (namaProfile.equals("eminacosmetics")) {
                // Open PostinganActivity or ProfileActivity with corresponding data
                Intent profileIntent = new Intent(StoryActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",  R.drawable.emina);
                profileIntent.putExtra("NAMA PROFILE", "eminacosmetics");
                profileIntent.putExtra("FOLLOWERS", "1M");
                profileIntent.putExtra("FOLLOWING","41");
                profileIntent.putExtra("POSTINGAN" , R.drawable.postemina);
                startActivity(profileIntent);
            }
        });
    }
}