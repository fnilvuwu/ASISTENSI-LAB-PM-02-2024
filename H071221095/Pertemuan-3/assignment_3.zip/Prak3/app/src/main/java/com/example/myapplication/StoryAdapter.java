package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder>{

    private final ArrayList<Story> stories;

    private Context context;

    public StoryAdapter(ArrayList<Story> stories, Context context) {
        this.context = context;
        this.stories = stories;
    }

    @NonNull
    @Override
    public StoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoryAdapter.ViewHolder holder, int position) {
        Story story = stories.get(position);
        holder.setData(story);

        holder.imageView.setOnClickListener(v -> {
            if(stories.get(position).getImage().equals(R.drawable.bnb)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.bnb);
                intent.putExtra("NAMA PROFILE", "barenbliss_id");
                intent.putExtra("STORY",R.drawable.storybnb);
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.rare)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.rare);
                intent.putExtra("NAMA PROFILE", "rarebeauty");
                intent.putExtra("STORY",R.drawable.storyrare);
                context.startActivity(intent);
            } if(stories.get(position).getImage().equals(R.drawable.luxcrime)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.luxcrime);
                intent.putExtra("NAMA PROFILE", "luxcrime_id");
                intent.putExtra("STORY",R.drawable.storyluxc);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.makeov)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.makeov);
                intent.putExtra("NAMA PROFILE", "makeoverid");
                intent.putExtra("STORY",R.drawable.storymake);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.somethinc)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.somethinc);
                intent.putExtra("NAMA PROFILE", "somethincofficial");
                intent.putExtra("STORY",R.drawable.storysome);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.esqa)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.esqa);
                intent.putExtra("NAMA PROFILE", "esqacosmetics");
                intent.putExtra("STORY",R.drawable.storyesqa);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.skintific)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.skintific);
                intent.putExtra("NAMA PROFILE", "skintificid");
                intent.putExtra("STORY",R.drawable.storyskin);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.mop)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.mop);
                intent.putExtra("NAMA PROFILE", "mop.beauty");
                intent.putExtra("STORY",R.drawable.storymop);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.foc)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.foc);
                intent.putExtra("NAMA PROFILE", "focallurebeauty");
                intent.putExtra("STORY",R.drawable.storyfoc);
                context.startActivity(intent);
            }if(stories.get(position).getImage().equals(R.drawable.emina)){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.emina);
                intent.putExtra("NAMA PROFILE", "eminacosmetics");
                intent.putExtra("STORY",R.drawable.storyemina);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return stories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView imageView;
        private final TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_nama);
            imageView = itemView.findViewById(R.id.iv_story);
        }

        public void setData(Story story) {
            textView.setText(story.getNama());
            imageView.setImageResource(story.getImage());
        };

    }
}
