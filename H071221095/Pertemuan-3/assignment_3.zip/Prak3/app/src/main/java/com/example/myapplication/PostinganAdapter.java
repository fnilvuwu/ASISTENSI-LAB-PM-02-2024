package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostinganAdapter extends RecyclerView.Adapter<PostinganAdapter.ViewHolder> {

    private final ArrayList<Postingan> postingans;

    private Context context;

    public PostinganAdapter(ArrayList<Postingan> postingans, Context context) {
        this.context =context;
        this.postingans = postingans;
    }

    @NonNull
    @Override
    public PostinganAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_post,parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostinganAdapter.ViewHolder holder, int position) {
        Postingan postingan = postingans.get(position);
        holder.setData(postingan);

        holder.tvUser.setOnClickListener(v -> {
            if(postingans.get(position).getUsername().equals("barenbliss_id")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.bnb);
                intent.putExtra("NAMA PROFILE","barenbliss_id");
                intent.putExtra("FOLLOWERS","185K");
                intent.putExtra("FOLLOWING","13");
                intent.putExtra("POSTINGAN", R.drawable.postbnb);
                context.startActivity(intent);
            }  if(postingans.get(position).getUsername().equals("rarebeauty")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.rare);
                intent.putExtra("NAMA PROFILE","rarebeauty");
                intent.putExtra("FOLLOWERS","7,2M");
                intent.putExtra("FOLLOWING","353");
                intent.putExtra("POSTINGAN", R.drawable.postrare);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("luxcrime_id")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.luxcrime);
                intent.putExtra("NAMA PROFILE","luxcrime_id");
                intent.putExtra("FOLLOWERS","680K");
                intent.putExtra("FOLLOWING","225");
                intent.putExtra("POSTINGAN", R.drawable.postluxc);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("makeoverid")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.makeov);
                intent.putExtra("NAMA PROFILE","makeoverid");
                intent.putExtra("FOLLOWERS","1,3M");
                intent.putExtra("FOLLOWING","174");
                intent.putExtra("POSTINGAN", R.drawable.postmake);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("somethincofficial")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.somethinc);
                intent.putExtra("NAMA PROFILE","somethincofficial");
                intent.putExtra("FOLLOWERS","1,4M");
                intent.putExtra("FOLLOWING","2.093");
                intent.putExtra("POSTINGAN", R.drawable.postsome);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("esqacosmetics")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.esqa);
                intent.putExtra("NAMA PROFILE","esqacosmetics");
                intent.putExtra("FOLLOWERS","295K");
                intent.putExtra("FOLLOWING","14");
                intent.putExtra("POSTINGAN", R.drawable.postesqa);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("skintificid")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.skintific);
                intent.putExtra("NAMA PROFILE","skintificid");
                intent.putExtra("FOLLOWERS","829K");
                intent.putExtra("FOLLOWING","67");
                intent.putExtra("POSTINGAN", R.drawable.postskin);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("mop.beauty")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.mop);
                intent.putExtra("NAMA PROFILE","mop.beauty");
                intent.putExtra("FOLLOWERS","387K");
                intent.putExtra("FOLLOWING","1");
                intent.putExtra("POSTINGAN", R.drawable.postmop);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("focallurebeauty")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.foc);
                intent.putExtra("NAMA PROFILE","focallurebeauty");
                intent.putExtra("FOLLOWERS","279K");
                intent.putExtra("FOLLOWING","270");
                intent.putExtra("POSTINGAN", R.drawable.postfoc);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("eminacosmetics")){
                Intent intent = new Intent(context, ProfileActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.emina);
                intent.putExtra("NAMA PROFILE","eminacosmetics");
                intent.putExtra("FOLLOWERS","1M");
                intent.putExtra("FOLLOWING","41");
                intent.putExtra("POSTINGAN", R.drawable.postemina);
                context.startActivity(intent);
            }
        });
        holder.imageView2.setOnClickListener(v -> {
            if(postingans.get(position).getUsername().equals("barenbliss_id")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.bnb);
                intent.putExtra("NAMA PROFILE", "barenbliss_id");
                intent.putExtra("STORY",R.drawable.storybnb);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("rarebeauty")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.rare);
                intent.putExtra("NAMA PROFILE", "rarebeauty");
                intent.putExtra("STORY",R.drawable.storyrare);
                context.startActivity(intent);
            } if(postingans.get(position).getUsername().equals("luxcrime_id")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.luxcrime);
                intent.putExtra("NAMA PROFILE", "luxcrime_id");
                intent.putExtra("STORY",R.drawable.storyluxc);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("makeoverid")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.makeov);
                intent.putExtra("NAMA PROFILE", "makeoverid");
                intent.putExtra("STORY",R.drawable.storymake);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("somethincofficial")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.somethinc);
                intent.putExtra("NAMA PROFILE", "somethincofficial");
                intent.putExtra("STORY",R.drawable.storysome);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("esqacosmetics")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.esqa);
                intent.putExtra("NAMA PROFILE", "esqacosmetics");
                intent.putExtra("STORY",R.drawable.storyesqa);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("skintificid")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.skintific);
                intent.putExtra("NAMA PROFILE", "skintificid");
                intent.putExtra("STORY",R.drawable.storyskin);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("mop.beauty")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.mop);
                intent.putExtra("NAMA PROFILE", "mop.beauty");
                intent.putExtra("STORY",R.drawable.storymop);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("focallurebeauty")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.foc);
                intent.putExtra("NAMA PROFILE", "focallurebeauty");
                intent.putExtra("STORY",R.drawable.storyfoc);
                context.startActivity(intent);
            }if(postingans.get(position).getUsername().equals("eminacosmetics")){
                Intent intent = new Intent(context, StoryActivity.class);
                intent.putExtra("FOTO PROFILE",R.drawable.emina);
                intent.putExtra("NAMA PROFILE", "eminacosmetics");
                intent.putExtra("STORY",R.drawable.storyemina);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return postingans.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView imageView, imageView2;

        private final TextView tvUser, tvDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView2 = itemView.findViewById(R.id.iv_profile);
            imageView = itemView.findViewById(R.id.iv_post);
            tvUser = itemView.findViewById(R.id.tv_user);
            tvDesc = itemView.findViewById(R.id.tv_desc);
        }

        public void setData(Postingan postingan) {
            imageView2.setImageResource(postingan.getImage2());
            imageView.setImageResource(postingan.getImage());
            tvUser.setText(postingan.getUsername());
            tvDesc.setText(postingan.getDesc());
        }
    }
}
