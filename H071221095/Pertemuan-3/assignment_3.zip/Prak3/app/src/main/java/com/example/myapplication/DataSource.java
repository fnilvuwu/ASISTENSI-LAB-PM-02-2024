package com.example.myapplication;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Postingan> postingans = generateDummyPostingans();

    private static ArrayList<Postingan> generateDummyPostingans() {
        ArrayList<Postingan> postingans = new ArrayList<>();
        postingans.add(new Postingan(R.drawable.bnb,"barenbliss_id", R.drawable.postbnb, "B+N+B Joyfull Clean Beauty"));
        postingans.add(new Postingan(R.drawable.rare,"rarebeauty", R.drawable.postrare, "Made to Feel Good in"));
        postingans.add(new Postingan(R.drawable.luxcrime,"luxcrime_id", R.drawable.postluxc, "I, Makeup, Skin, Happy"));
        postingans.add(new Postingan(R.drawable.makeov,"makeoverid", R.drawable.postmake, "The Most Extensive Complexion Shades"));
        postingans.add(new Postingan(R.drawable.somethinc,"somethincofficial", R.drawable.postsome, "Be you, Be somethinc"));
        postingans.add(new Postingan(R.drawable.esqa,"esqacosmetics", R.drawable.postesqa, "Indonesia's 1st Vegan cosmetics brand"));
        postingans.add(new Postingan(R.drawable.skintific,"skintificid", R.drawable.postskin, "Perfect coverage and long-lasting!"));
        postingans.add(new Postingan(R.drawable.mop,"mop.beauty", R.drawable.postmop, "MotherofPearl, MotherKnowsBest"));
        postingans.add(new Postingan(R.drawable.foc,"focallurebeauty", R.drawable.postfoc, "Color the Life"));
        postingans.add(new Postingan(R.drawable.emina,"eminacosmetics", R.drawable.postemina, "Let's discover our authentic beauty together!"));
        return postingans;
    }

    public static ArrayList<Story> stories = generateDummyStorys();

    private static ArrayList<Story> generateDummyStorys() {
        ArrayList<Story> stories = new ArrayList<>();
        stories.add(new Story("barenbliss_id",R.drawable.bnb));
        stories.add(new Story("rarebeauty",R.drawable.rare));
        stories.add(new Story("luxcrime_id",R.drawable.luxcrime));
        stories.add(new Story("makeoverid",R.drawable.makeov));
        stories.add(new Story("somethinc",R.drawable.somethinc));
        stories.add(new Story("esqa",R.drawable.esqa));
        stories.add(new Story("skintificid",R.drawable.skintific));
        stories.add(new Story("mop.beauty",R.drawable.mop));
        stories.add(new Story("focallure",R.drawable.foc));
        stories.add(new Story("emina",R.drawable.emina));
        return stories;
    }
}
