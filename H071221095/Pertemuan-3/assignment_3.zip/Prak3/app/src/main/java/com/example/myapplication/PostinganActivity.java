package com.example.myapplication;

import android.app.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PostinganActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postingan_actvity);

        ImageView ivProfile = findViewById(R.id.iv_profile);
        TextView tvUsername = findViewById(R.id.tv_user);
        ImageView ivPost = findViewById(R.id.iv_post);
        TextView tvDesc = findViewById(R.id.tv_desc);

        Intent intent = getIntent();

        int fotoProfile = intent.getIntExtra("FOTO PROFILE",0);
        String username = intent.getStringExtra("USERNAME");
        int postingan = intent.getIntExtra("POSTINGAN", 0);
        String desc = intent.getStringExtra("DESKRIPSI");

        ivProfile.setImageResource(fotoProfile);
        tvUsername.setText(username);
        ivPost.setImageResource(postingan);
        tvDesc.setText(desc);

        ivProfile.setOnClickListener(v -> {
            if(fotoProfile == R.drawable.bnb){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.bnb);
                Storyintent.putExtra("NAMA PROFILE", "barenbliss_id");
                Storyintent.putExtra("STORY",R.drawable.storybnb);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.rare){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.rare);
                Storyintent.putExtra("NAMA PROFILE", "rarebeauty");
                Storyintent.putExtra("STORY",R.drawable.storyrare);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.luxcrime){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.luxcrime);
                Storyintent.putExtra("NAMA PROFILE", "luxcrime_id");
                Storyintent.putExtra("STORY",R.drawable.storyluxc);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.makeov){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.makeov);
                Storyintent.putExtra("NAMA PROFILE", "makeoverid");
                Storyintent.putExtra("STORY",R.drawable.storymake);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.somethinc){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.somethinc);
                Storyintent.putExtra("NAMA PROFILE", "somethincofficial");
                Storyintent.putExtra("STORY",R.drawable.storysome);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.esqa){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.esqa);
                Storyintent.putExtra("NAMA PROFILE", "esqacosmetics");
                Storyintent.putExtra("STORY",R.drawable.storyesqa);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.skintific){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.skintific);
                Storyintent.putExtra("NAMA PROFILE", "skintificid");
                Storyintent.putExtra("STORY",R.drawable.storyskin);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.mop){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.mop);
                Storyintent.putExtra("NAMA PROFILE", "mop.beauty");
                Storyintent.putExtra("STORY",R.drawable.storymop);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.foc){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.foc);
                Storyintent.putExtra("NAMA PROFILE", "focallurebeauty");
                Storyintent.putExtra("STORY",R.drawable.storyfoc);
                startActivity(Storyintent);
            }if(fotoProfile == R.drawable.emina){
                Intent Storyintent = new Intent(PostinganActivity.this, StoryActivity.class);
                Storyintent.putExtra("FOTO PROFILE",R.drawable.emina);
                Storyintent.putExtra("NAMA PROFILE", "eminacosmetics");
                Storyintent.putExtra("STORY",R.drawable.storyemina);
                startActivity(Storyintent);
            }
        });

        tvUsername.setOnClickListener(v -> {
            if(username.equals("barenbliss_id")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.bnb);
                profileIntent.putExtra("NAMA PROFILE","barenbliss_id");
                profileIntent.putExtra("FOLLOWERS","185K");
                profileIntent.putExtra("FOLLOWING","13");
                profileIntent.putExtra("POSTINGAN", R.drawable.postbnb);
                startActivity((profileIntent));
            }if(username.equals("rarebeauty")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.rare);
                profileIntent.putExtra("NAMA PROFILE","rarebeauty");
                profileIntent.putExtra("FOLLOWERS","7,2M");
                profileIntent.putExtra("FOLLOWING","353");
                profileIntent.putExtra("POSTINGAN", R.drawable.postrare);
                startActivity((profileIntent));
            } if(username.equals("luxcrime_id")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.luxcrime);
                profileIntent.putExtra("NAMA PROFILE","luxcrime_id");
                profileIntent.putExtra("FOLLOWERS","680K");
                profileIntent.putExtra("FOLLOWING","225");
                profileIntent.putExtra("POSTINGAN", R.drawable.postluxc);
                startActivity((profileIntent));
            } if(username.equals("makeoverid")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.makeov);
                profileIntent.putExtra("NAMA PROFILE","makeoverid");
                profileIntent.putExtra("FOLLOWERS","1,3M");
                profileIntent.putExtra("FOLLOWING","174");
                profileIntent.putExtra("POSTINGAN", R.drawable.postmake);
                startActivity((profileIntent));
            }if(username.equals("somethincofficial")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.somethinc);
                profileIntent.putExtra("NAMA PROFILE","somethincofficial");
                profileIntent.putExtra("FOLLOWERS","1,4M");
                profileIntent.putExtra("FOLLOWING","2.093");
                profileIntent.putExtra("POSTINGAN", R.drawable.postsome);
                startActivity((profileIntent));
            }if(username.equals("esqacosmetics")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.esqa);
                profileIntent.putExtra("NAMA PROFILE","esqacosmetics");
                profileIntent.putExtra("FOLLOWERS","295K");
                profileIntent.putExtra("FOLLOWING","14");
                profileIntent.putExtra("POSTINGAN", R.drawable.postesqa);
                startActivity((profileIntent));
            }if(username.equals("skintificid")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.skintific);
                profileIntent.putExtra("NAMA PROFILE","skintificid");
                profileIntent.putExtra("FOLLOWERS","829K");
                profileIntent.putExtra("FOLLOWING","67");
                profileIntent.putExtra("POSTINGAN", R.drawable.postskin);
                startActivity((profileIntent));
            } if(username.equals("mop.beauty")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.mop);
                profileIntent.putExtra("NAMA PROFILE","mop.beauty");
                profileIntent.putExtra("FOLLOWERS","387K");
                profileIntent.putExtra("FOLLOWING","1");
                profileIntent.putExtra("POSTINGAN", R.drawable.postmop);
                startActivity((profileIntent));
            }if(username.equals("focallurebeauty")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.foc);
                profileIntent.putExtra("NAMA PROFILE","focallurebeauty");
                profileIntent.putExtra("FOLLOWERS","279K");
                profileIntent.putExtra("FOLLOWING","270");
                profileIntent.putExtra("POSTINGAN", R.drawable.postfoc);
                startActivity((profileIntent));
            } if(username.equals("eminacosmetics")){
                Intent profileIntent = new Intent(PostinganActivity.this, ProfileActivity.class);
                profileIntent.putExtra("FOTO PROFILE",R.drawable.emina);
                profileIntent.putExtra("NAMA PROFILE","eminacosmetics");
                profileIntent.putExtra("FOLLOWERS","1M");
                profileIntent.putExtra("FOLLOWING","41");
                profileIntent.putExtra("POSTINGAN", R.drawable.postemina);
                startActivity((profileIntent));
            }
        });
    }

}
