package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView ivProfile = findViewById(R.id.iv_profile);
        TextView tvProfile = findViewById(R.id.Tv_profile);
        TextView tvAngkaFollowers = findViewById(R.id.Tv_followers);
        TextView tvAngkaFollowing = findViewById(R.id.Tv_following);
        ImageView ivPost = findViewById(R.id.iv_post);

        Intent intent = getIntent();

        int fotoProfile = intent.getIntExtra("FOTO PROFILE", 0);
        String namaProfile = intent.getStringExtra("NAMA PROFILE");
        String angkaFollowers = intent.getStringExtra("FOLLOWERS");
        String angkaFollowing = intent.getStringExtra("FOLLOWING");
        int postingan = intent.getIntExtra("POSTINGAN", 0);

        ivProfile.setImageResource(fotoProfile);
        tvProfile.setText(namaProfile);
        tvAngkaFollowers.setText(angkaFollowers);
        tvAngkaFollowing.setText(angkaFollowing);
        ivPost.setImageResource(postingan);

        ivProfile.setOnClickListener(v -> {
            if (fotoProfile == R.drawable.bnb) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.bnb);
                storyIntent.putExtra("NAMA PROFILE", "barenbliss_id");
                storyIntent.putExtra("STORY", R.drawable.storybnb);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.rare) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.rare);
                storyIntent.putExtra("NAMA PROFILE", "rarebeauty");
                storyIntent.putExtra("STORY", R.drawable.storyrare);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.luxcrime) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.luxcrime);
                storyIntent.putExtra("NAMA PROFILE", "luxcrime_id");
                storyIntent.putExtra("STORY", R.drawable.storyluxc);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.makeov) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.makeov);
                storyIntent.putExtra("NAMA PROFILE", "makeoverid");
                storyIntent.putExtra("STORY", R.drawable.storymake);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.somethinc) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.somethinc);
                storyIntent.putExtra("NAMA PROFILE", "somethincofficial");
                storyIntent.putExtra("STORY", R.drawable.storysome);
                startActivity(storyIntent);
            }  if (fotoProfile == R.drawable.esqa) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.esqa);
                storyIntent.putExtra("NAMA PROFILE", "esqacosmetics");
                storyIntent.putExtra("STORY", R.drawable.storyesqa);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.skintific) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.skintific);
                storyIntent.putExtra("NAMA PROFILE", "skintificid");
                storyIntent.putExtra("STORY", R.drawable.storyskin);
                startActivity(storyIntent);
            } if (fotoProfile == R.drawable.mop) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.mop);
                storyIntent.putExtra("NAMA PROFILE", "mop.beauty");
                storyIntent.putExtra("STORY", R.drawable.storymop);
                startActivity(storyIntent);
            } else if (fotoProfile == R.drawable.foc) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.foc);
                storyIntent.putExtra("NAMA PROFILE", "focallurebeauty");
                storyIntent.putExtra("STORY", R.drawable.storyfoc);
                startActivity(storyIntent);
            } else if (fotoProfile == R.drawable.emina) {
                Intent storyIntent = new Intent(ProfileActivity.this, StoryActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.emina);
                storyIntent.putExtra("NAMA PROFILE", "eminacosmetics");
                storyIntent.putExtra("STORY", R.drawable.storyemina);
                startActivity(storyIntent);
            }
        });

        ivPost.setOnClickListener(v -> {
            if (postingan == R.drawable.postbnb) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.bnb);
                storyIntent.putExtra("USERNAME", "barenbliss_id");
                storyIntent.putExtra("POSTINGAN", R.drawable.postbnb);
                storyIntent.putExtra("DESKRIPSI", "B+N+B Joyful Clean Beauty");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postrare) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.rare);
                storyIntent.putExtra("USERNAME", "rarebeauty");
                storyIntent.putExtra("POSTINGAN", R.drawable.postrare);
                storyIntent.putExtra("DESKRIPSI", "Made to Feel Good in");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postluxc) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.luxcrime);
                storyIntent.putExtra("USERNAME", "luxcrime_id");
                storyIntent.putExtra("POSTINGAN", R.drawable.postluxc);
                storyIntent.putExtra("DESKRIPSI", "I, Makeup, Skin, Happy");
                startActivity(storyIntent);
            }if (postingan == R.drawable.postmake) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.makeov);
                storyIntent.putExtra("USERNAME", "makeoverid");
                storyIntent.putExtra("POSTINGAN", R.drawable.postmake);
                storyIntent.putExtra("DESKRIPSI", "The Most Extensive Complexion Shades");
                startActivity(storyIntent);
            }if (postingan == R.drawable.postsome) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.somethinc);
                storyIntent.putExtra("USERNAME", "somethincofficial");
                storyIntent.putExtra("POSTINGAN", R.drawable.postsome);
                storyIntent.putExtra("DESKRIPSI", "Be you, Be somethinc");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postesqa) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.esqa);
                storyIntent.putExtra("USERNAME", "esqacosmmetics");
                storyIntent.putExtra("POSTINGAN", R.drawable.postesqa);
                storyIntent.putExtra("DESKRIPSI", "Indonesia's 1st Vegan cosmetics brand");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postskin) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.skintific);
                storyIntent.putExtra("USERNAME", "skintificid");
                storyIntent.putExtra("POSTINGAN", R.drawable.postskin);
                storyIntent.putExtra("DESKRIPSI", "Perfect coverage and long-lasting!");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postmop) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.mop);
                storyIntent.putExtra("USERNAME", "mop.beauty");
                storyIntent.putExtra("POSTINGAN", R.drawable.postmop);
                storyIntent.putExtra("DESKRIPSI", "MotherofPearl, MotherKnowsBest");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postfoc) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.foc);
                storyIntent.putExtra("USERNAME", "focallurebeauty");
                storyIntent.putExtra("POSTINGAN", R.drawable.postfoc);
                storyIntent.putExtra("DESKRIPSI", "Color the Life");
                startActivity(storyIntent);
            } if (postingan == R.drawable.postemina) {
                Intent storyIntent = new Intent(ProfileActivity.this, PostinganActivity.class);
                storyIntent.putExtra("FOTO PROFILE", R.drawable.emina);
                storyIntent.putExtra("USERNAME", "eminacosmetics");
                storyIntent.putExtra("POSTINGAN", R.drawable.postemina);
                storyIntent.putExtra("DESKRIPSI", "Let's discover our authentic beauty together!");
                startActivity(storyIntent);
            }
        });
    }
}
