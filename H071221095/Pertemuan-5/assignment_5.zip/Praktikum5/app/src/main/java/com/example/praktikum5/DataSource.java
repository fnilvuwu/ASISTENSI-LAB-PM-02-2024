package com.example.praktikum5;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams =generateDummyInstagram();

    private static ArrayList<Instagram> generateDummyInstagram() {
        ArrayList<Instagram> instagrams1 = new ArrayList<>();
        instagrams1.add(new Instagram("rarebeauty", "Rare Beauty by Selena", "Fill in the blank: I find comfort in...... (Drop your answer in the comments)"
                ,R.drawable.rare, R.drawable.postrare));

        instagrams1.add(new Instagram("luxcrime_id", "Luxcrime Cosmetics & Beauty", "Upgrade your makeup game with Blur & Cover Two Way Cake's new version"
                ,R.drawable.luxcrime, R.drawable.postluxc));

        instagrams1.add(new Instagram("focallurebeauty", "Focallure Indonesia", "Beautiful lip wraps for your lips with colors that are suitable for various skin tones"
                ,R.drawable.foc, R.drawable.postfoc));

        instagrams1.add(new Instagram("makeoverid", "Make Over Cosmetics", "Powerstay 24H Matte Powder Foundation"
                ,R.drawable.makeov, R.drawable.postmake));

        instagrams1.add(new Instagram("esqacosmetics", "Esqa Cosmetics", "Ready to be the talk of the town?"
                ,R.drawable.esqa, R.drawable.postesqa));

        return instagrams1;

    }

}

