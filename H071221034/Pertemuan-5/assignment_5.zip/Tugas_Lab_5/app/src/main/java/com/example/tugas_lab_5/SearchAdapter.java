package com.example.tugas_lab_5;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder> {

    private ArrayList<Instagram> instagrams;

    public SearchAdapter(ArrayList<Instagram> instagrams) {
        this.instagrams = instagrams;
    }

    @NonNull
    @Override
    public SearchAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search, parent, false);
        return new SearchAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SearchAdapter.ViewHolder holder, int position) {
        Instagram instagram = instagrams.get(position);

        holder.iv_profile_pict.setImageResource(instagram.getFoto_profil());
        holder.tv_name.setText(instagram.getName());
        holder.tv_fullname.setText(instagram.getFullname());

        holder.iv_profile_pict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, ProfileActivity.class);
                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });

        holder.tv_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, ProfileActivity.class);
                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });

        holder.tv_fullname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, ProfileActivity.class);
                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });
    }

    public void filteredList(ArrayList<Instagram> filteredList) {
        instagrams = filteredList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return instagrams.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView iv_profile_pict;
        TextView tv_name, tv_fullname;
        Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_profile_pict = itemView.findViewById(R.id.iv_profilepicture);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_fullname = itemView.findViewById(R.id.tv_fullname);
            context = itemView.getContext();
        }
    }
}
