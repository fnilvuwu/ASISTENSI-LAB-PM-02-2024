package com.example.tugas_lab_5;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder>{

    private ArrayList<Instagram> instagrams;

    public PostAdapter(ArrayList<Instagram> instagrams){
        this.instagrams = instagrams;
    }

    @NonNull
    @Override
    public PostAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post, parent, false);
        return new PostAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PostAdapter.ViewHolder holder, int position) {
        Instagram instagram = instagrams.get(position);

        holder.tv_name.setText(instagram.getName());
        holder.tv_fullname.setText(instagram.getFullname());
        holder.tv_caption.setText(instagram.getCaption());
        holder.iv_foto_profil.setImageResource(instagram.getFoto_profil());
        holder.iv_foto_feed.setImageResource(instagram.getFoto_feed());
        holder.iv_foto_post.setImageURI(instagram.getSelectedImageUri());
    }

    @Override
    public int getItemCount() {
        return instagrams.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tv_name, tv_fullname, tv_caption;
        ImageView iv_foto_profil, iv_foto_feed, iv_foto_post;

        Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_fullname = itemView.findViewById(R.id.tv_fullname);
            tv_caption = itemView.findViewById(R.id.tv_caption);
            iv_foto_profil = itemView.findViewById(R.id.iv_profilepictures);
            iv_foto_feed = itemView.findViewById(R.id.iv_post);
            iv_foto_post = itemView.findViewById(R.id.iv_post);
            context = itemView.getContext();
        }
    }
}
