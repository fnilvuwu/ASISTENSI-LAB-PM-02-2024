package com.example.tugas_lab_5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView iv_profile_pict = findViewById(R.id.iv_profilepicture);
        TextView tv_fullname = findViewById(R.id.tv_fullname);
        TextView tv_name = findViewById(R.id.tv_name);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        iv_profile_pict.setVisibility(View.GONE);
        tv_fullname.setVisibility(View.GONE);
        tv_name.setVisibility(View.GONE);

        progressBar.setVisibility(View.VISIBLE);

        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e){
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressBar.setVisibility(View.GONE);

                        iv_profile_pict.setVisibility(View.VISIBLE);
                        tv_fullname.setVisibility(View.VISIBLE);
                        tv_name.setVisibility(View.VISIBLE);

                        Intent intent = getIntent();
                        Instagram instagram = intent.getParcelableExtra("instagram");

                        iv_profile_pict.setImageResource(instagram.getFoto_profil());
                        tv_fullname.setText(instagram.getFullname());
                        tv_name.setText(instagram.getName());
                    }
                });
            }
        });
    }
}