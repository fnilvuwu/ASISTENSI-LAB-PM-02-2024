package com.example.tugas_lab_5;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagram();

    private static ArrayList<Instagram> generateDummyInstagram() {
        ArrayList<Instagram> instagrams = new ArrayList<>();
        instagrams.add(new Instagram("Dino", "Lee Chan", "행복했던 부산✈️", R.drawable.profil_dino, R.drawable.post_dino));
        instagrams.add(new Instagram("Woozi", "Lee Jihoon", "테무깡 대단하다\n" +
                "\n" +
                "출처 침하하", R.drawable.profil_woozi, R.drawable.post_woozi));
        instagrams.add(new Instagram("Joshua", "Hong Joshua", "🤍", R.drawable.profil_joshua, R.drawable.post_joshua));
        instagrams.add(new Instagram("Seungkwan", "Boo Seungkwan", "캐럿들 오늘 하루도 수고 많았어요!\n" +
                "전 오늘 스케줄 하고 들어와서 이제 자려고\n" +
                "준비하다가 이렇게 글을 쓰네요🖤 가끔\n" +
                "손글씨로도 인사할게요 꿈에서 만나자~!!\n" +
                "나랑 꿈에서 배드민턴 크아 산책 치맥 다 하자:)\n" +
                "오늘도 관랑해🤭", R.drawable.profil_seungkwan, R.drawable.post_seungkwan));
        instagrams.add(new Instagram("S.Coups", "Choi Seungcheol", "너무 늦은 출사", R.drawable.profil_scoups, R.drawable.post_scoups));
        instagrams.add((new Instagram("Wonwoo", "Jeon Wonwoo", "ㅋㅋㅋㅋㅋㅋ꿀잼!", R.drawable.profil_wonwoo, R.drawable.post_wonwoo)));
        instagrams.add(new Instagram("Hoshi", "Kwon Soonyoung", "사실.. 열기구가 있었다?\n" +
                "바람이 불어서 못했오..🥲" +
                "\n", R.drawable.profil_hoshi, R.drawable.post_hoshi));
        instagrams.add(new Instagram("Vernon", "Chwe Hansol", "이따 봐", R.drawable.profil_vernon, R.drawable.post_vernon));
        instagrams.add(new Instagram("Jun", "Moon Junhui", "🚶🌊", R.drawable.profil_jun, R.drawable.post_jun));
        instagrams.add(new Instagram("Jeonghan", "Yoon Jeonghan", "오랜만에 유학간 돌쫑이 근황보여줄게!!", R.drawable.profil_jeonghan, R.drawable.post_jeonghan));

        return instagrams;
    }
}
