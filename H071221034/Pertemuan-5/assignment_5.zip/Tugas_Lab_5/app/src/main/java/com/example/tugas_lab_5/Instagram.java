package com.example.tugas_lab_5;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Instagram implements Parcelable {

    private String name, fullname, caption;
    private int foto_profil, foto_feed;
    private Uri selectedImageUri;

    public Instagram(String name, String fullname, String caption, int foto_profil, int foto_feed) {
        this.name = name;
        this.fullname = fullname;
        this.caption = caption;
        this.foto_profil = foto_profil;
        this.foto_feed = foto_feed;
    }

    public Instagram(String name, String fullname, String caption, int foto_profil, Uri selectedImageUri) {
        this.name = name;
        this.fullname = fullname;
        this.caption = caption;
        this.foto_profil = foto_profil;
        this.selectedImageUri = selectedImageUri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getFoto_profil() {
        return foto_profil;
    }

    public void setFoto_profil(int foto_profil) {
        this.foto_profil = foto_profil;
    }

    public int getFoto_feed() {
        return foto_feed;
    }

    public void setFoto_feed(int foto_feed) {
        this.foto_feed = foto_feed;
    }

    public Uri getSelectedImageUri() {
        return selectedImageUri;
    }

    public void setSelectedImageUri(Uri selectedImageUri) {
        this.selectedImageUri = selectedImageUri;
    }

    protected Instagram(Parcel in) {
        name = in.readString();
        fullname = in.readString();
        caption = in.readString();
        foto_profil = in.readInt();
        foto_feed = in.readInt();
    }

    public static final Creator<Instagram> CREATOR = new Creator<Instagram>() {
        @Override
        public Instagram createFromParcel(Parcel in) {
            return new Instagram(in);
        }

        @Override
        public Instagram[] newArray(int size) {
            return new Instagram[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(fullname);
        dest.writeString(caption);
        dest.writeInt(foto_profil);
        dest.writeInt(foto_feed);
    }
}
