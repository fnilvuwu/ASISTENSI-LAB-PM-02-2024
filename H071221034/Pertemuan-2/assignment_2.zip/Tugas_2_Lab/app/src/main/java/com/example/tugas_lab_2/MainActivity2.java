package com.example.tugas_lab_2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    private EditText editText1;
    private EditText editText2;
    private Button button;
    private Uri uri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editText1 = findViewById(R.id.edittext3);
        editText2 = findViewById(R.id.edittext4);
        button = findViewById(R.id.button2);

        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String username = intent.getStringExtra("username");
        uri = intent.getParcelableExtra("image");

        button.setOnClickListener(view -> {
            if (IsValidInput()){
                String editText1Value = editText1.getText().toString();
                String editText2Value = editText2.getText().toString();
                Intent move2 = new Intent(this, MainActivity3.class);

                move2.putExtra("nama", nama);
                move2.putExtra("username", username);
                move2.putExtra("image", uri);

                move2.putExtra("title", editText1Value);
                move2.putExtra("content", editText2Value);

                startActivity(move2);
            }
        });
    }

    private boolean IsValidInput(){
        if (editText1.getText().toString().isEmpty()){
            editText1.setError("Title is required");
            return false;
        }

        if (editText2.getText().toString().isEmpty()){
            editText2.setError("Content is required");
            return false;
        }

        return true;
    }
}