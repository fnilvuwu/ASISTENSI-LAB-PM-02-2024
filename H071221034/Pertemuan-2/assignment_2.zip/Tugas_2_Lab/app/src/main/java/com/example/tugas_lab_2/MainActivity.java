package com.example.tugas_lab_2;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button button;
    private EditText editText1;
    private EditText editText2;
    private ImageView imageView;
    private Uri uri;
    private ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });

        actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#8B93FF")));
        actionBar.setTitle("Tugas Praktikum Intent");

        button = findViewById(R.id.button1);
        editText1 = findViewById(R.id.edittext1);
        editText2 = findViewById(R.id.edittext2);
        imageView = findViewById(R.id.imageview1);

        button.setOnClickListener(view -> {
            if (isValidInput()){
                String editText1Value = editText1.getText().toString();
                String editText2Value = editText2.getText().toString();
                Intent move = new Intent(this, MainActivity2.class);
                move.putExtra("nama", editText1Value);
                move.putExtra("username", editText2Value);
                move.putExtra("image", uri);

                startActivity(move);
            }
        });

        imageView.setOnClickListener(view -> {
            Intent openGallery = new Intent(Intent.ACTION_PICK);
            openGallery.setType("image/*");
            launcherIntentGallery.launch(openGallery);
        });
    }

    private boolean isValidInput() {
        if (editText1.getText().toString().isEmpty()){
            editText1.setError("Name is required");
            return false;
        }

        if (editText2.getText().toString().isEmpty()){
            editText2.setError("Username is required!");
            return false;
        }
        if (uri == null){
            Toast.makeText(this, "Please enter an image", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    ActivityResultLauncher<Intent> launcherIntentGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK){
                    Intent data = result.getData();
                    if(data != null){
                        uri = data.getData();
                        imageView.setImageURI(uri);
                    }
                }
            }
    );
}