package com.example.tugas_lab_6;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TextView tv_connection_lost;
    ProgressBar progressBar;
    Button btn_retry, btn_load_more;
    AdapterUsers adapterUsers;
    int currentPage = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        tv_connection_lost = findViewById(R.id.tv_connection_lost);
        progressBar = findViewById(R.id.progressBar);
        btn_retry = findViewById(R.id.btn_retry);
        btn_load_more = findViewById(R.id.btn_load_more);

        adapterUsers = new AdapterUsers(new ArrayList<>());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapterUsers);

        calling(currentPage);

        btn_load_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPage++;
                loadMore();
            }
        });
    }

    public void calling(int page) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        tv_connection_lost.setVisibility(View.GONE);
        btn_retry.setVisibility(View.GONE);
        progressBar.setVisibility(View.VISIBLE);
        btn_load_more.setVisibility(View.GONE);

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Call<DataResponse> client = ApiConfig.getApiService().getData(String.valueOf(currentPage));
                client.enqueue(new Callback<DataResponse>() {
                    @Override
                    public void onResponse(Call<DataResponse> call, Response<DataResponse> response) {
                        if (response.isSuccessful()) {
                            if (response.body() != null) {
                                ArrayList<UserResponse> userResponses = response.body().getData();
                                adapterUsers.addData(userResponses);
                                progressBar.setVisibility(View.GONE);
                                btn_load_more.setVisibility(View.VISIBLE);
                            }
                        } else {
                            if (response.body() != null) {
                                Log.e("MainActivity", "onFailure: " + response.message());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<DataResponse> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        tv_connection_lost.setVisibility(View.VISIBLE);
                        btn_retry.setVisibility(View.VISIBLE);

                        btn_retry.setOnClickListener(v -> {
                            progressBar.setVisibility(View.VISIBLE);
                            tv_connection_lost.setVisibility(View.GONE);
                            btn_retry.setVisibility(View.GONE);
                            calling(currentPage);
                        });
                    }
                });
            }
        });
    }

    private void loadMore() {
        calling(currentPage);
    }
}