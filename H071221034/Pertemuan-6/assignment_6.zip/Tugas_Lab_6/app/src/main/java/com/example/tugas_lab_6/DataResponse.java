package com.example.tugas_lab_6;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class DataResponse {

    @SerializedName("data")
    private final ArrayList<UserResponse> data;

    public DataResponse(ArrayList<UserResponse> data) {
        this.data = data;
    }

    public ArrayList<UserResponse> getData(){
        return data;
    }
}
