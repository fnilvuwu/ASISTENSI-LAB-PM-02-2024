package com.example.tugas_lab_6;

import com.google.gson.annotations.SerializedName;

public class ProfileResponse {
    @SerializedName("data")
    private UserResponse data;

    public UserResponse getData(){
        return data;
    }
}
