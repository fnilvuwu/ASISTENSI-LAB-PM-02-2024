package com.example.tugas_lab_6;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.squareup.picasso.Picasso;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends AppCompatActivity {

    ImageView iv_foto_profil;
    Button btn_retry;
    TextView tv_name, tv_email, tv_connection_lost;
    ProgressBar progressBar;
    CardView card_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        iv_foto_profil = findViewById(R.id.iv_foto_profil);
        btn_retry = findViewById(R.id.btn_retry);
        tv_name = findViewById(R.id.tv_name);
        tv_email = findViewById(R.id.tv_email);
        tv_connection_lost = findViewById(R.id.tv_connection_lost);
        progressBar = findViewById(R.id.progressBar);
        card_view = findViewById(R.id.card_view);

        calling();
    }

    public void calling() {
        String id = getIntent().getStringExtra("id");

        tv_connection_lost.setVisibility(View.GONE);
        btn_retry.setVisibility(View.GONE);
        card_view.setVisibility(View.GONE);

        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executorService.execute(new Runnable() {
            @Override
            public void run() {
                Call<ProfileResponse> client = ApiConfig.getApiService().getUser(id);
                client.enqueue(new Callback<ProfileResponse>() {
                    @Override
                    public void onResponse(Call<ProfileResponse> call, Response<ProfileResponse> response) {
                        if (response.isSuccessful()) {
                            if (response.body() != null) {
                                UserResponse userResponse = response.body().getData();

                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        tv_name.setText(userResponse.getFirstName() + userResponse.getLastName());
                                        tv_email.setText(userResponse.getEmail());
                                        Picasso.get().load(userResponse.getAvatarUrl()).into(iv_foto_profil);

                                        progressBar.setVisibility(View.GONE);
                                        card_view.setVisibility(View.VISIBLE);
                                    }
                                });
                            }
                        } else {
                            if (response.body() != null) {
                                Log.e("MainActivity", "onFailure1: " + response.message());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<ProfileResponse> call, Throwable t) {
                        progressBar.setVisibility(View.GONE);
                        tv_connection_lost.setVisibility(View.VISIBLE);
                        btn_retry.setVisibility(View.VISIBLE);

                        btn_retry.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                progressBar.setVisibility(View.VISIBLE);
                                tv_connection_lost.setVisibility(View.GONE);
                                btn_retry.setVisibility(View.GONE);
                                calling();
                            }
                        });
                    }
                });
            }
        });
    }
}