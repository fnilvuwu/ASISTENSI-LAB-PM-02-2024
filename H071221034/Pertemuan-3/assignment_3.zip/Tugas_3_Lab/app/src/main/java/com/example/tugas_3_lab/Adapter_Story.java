package com.example.tugas_3_lab;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter_Story extends RecyclerView.Adapter<Adapter_Story.ViewHolder>{

    private ArrayList<Instagram> instagrams;

    public Adapter_Story(ArrayList<Instagram> instagrams) {
        this.instagrams = instagrams;
    }

    @NonNull
    @Override
    public Adapter_Story.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_story, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_Story.ViewHolder holder, int position) {
        Instagram instagram = instagrams.get(position);

        holder.image_profile.setImageResource(instagram.getImage_profile());
        holder.username.setText(instagram.getUsername());

        holder.image_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, StoryActivity.class);

                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return instagrams.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView image_profile;
        private final TextView username;
        private final Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image_profile = itemView.findViewById(R.id.iv_profile_pictures);
            username = itemView.findViewById(R.id.tv_username);
            context = itemView.getContext();
        }
    }
}