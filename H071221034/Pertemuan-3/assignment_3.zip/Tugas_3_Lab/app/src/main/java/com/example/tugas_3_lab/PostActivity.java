package com.example.tugas_3_lab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PostActivity extends AppCompatActivity {
    private ImageView profile, post;
    private TextView username, caption;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        Intent intent = getIntent();

        Instagram instagram = intent.getParcelableExtra("instagram");

        profile = findViewById(R.id.iv_profilepictures_post);
        post = findViewById(R.id.iv_post2);
        username = findViewById(R.id.tv_account_post);
        caption = findViewById(R.id.tv_caption2);

        profile.setImageResource(instagram.getImage_profile());
        post.setImageResource(instagram.getImage_post());
        username.setText(instagram.getUsername());
        caption.setText(instagram.getCaption());

        username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PostActivity.this, ProfileActivity.class);
                intent.putExtra("instagram", instagram);
                startActivity(intent);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PostActivity.this, StoryActivity.class);
                intent.putExtra("instagram", instagram);
                startActivity(intent);
            }
        });
    }
}