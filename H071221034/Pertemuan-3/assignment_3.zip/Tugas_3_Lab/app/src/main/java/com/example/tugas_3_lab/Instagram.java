package com.example.tugas_3_lab;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Instagram implements Parcelable {

    private String username, caption, followers, following;

    private Integer image_profile, image_post, image_story;

    public Instagram(String username, String caption, String followers, String following, Integer image_profile, Integer image_post, Integer image_story) {
        this.username = username;
        this.caption = caption;
        this.followers = followers;
        this.following = following;
        this.image_profile = image_profile;
        this.image_post = image_post;
        this.image_story = image_story;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getFollowers() {
        return followers;
    }

    public void setFollowers(String followers) {
        this.followers = followers;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public Integer getImage_profile() {
        return image_profile;
    }

    public void setImage_profile(Integer image_profile) {
        this.image_profile = image_profile;
    }

    public Integer getImage_post() {
        return image_post;
    }

    public void setImage_post(Integer image_post) {
        this.image_post = image_post;
    }

    public Integer getImage_story() {
        return image_story;
    }

    public void setImage_story(Integer image_story) {
        this.image_story = image_story;
    }

    protected Instagram(Parcel in) {
        username = in.readString();
        caption = in.readString();
        followers = in.readString();
        following = in.readString();
        if (in.readByte() == 0) {
            image_profile = null;
        } else {
            image_profile = in.readInt();
        }
        if (in.readByte() == 0) {
            image_post = null;
        } else {
            image_post = in.readInt();
        }
        if (in.readByte() == 0) {
            image_story = null;
        } else {
            image_story = in.readInt();
        }
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(username);
        dest.writeString(caption);
        dest.writeString(followers);
        dest.writeString(following);
        if (image_profile == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(image_profile);
        }
        if (image_post == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(image_post);
        }
        if (image_story == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(image_story);
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Instagram> CREATOR = new Creator<Instagram>() {
        @Override
        public Instagram createFromParcel(Parcel in) {
            return new Instagram(in);
        }

        @Override
        public Instagram[] newArray(int size) {
            return new Instagram[size];
        }
    };




}
