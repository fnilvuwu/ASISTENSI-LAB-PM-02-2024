package com.example.tugas_3_lab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {

    private ImageView profile, post;
    private TextView username, followers, following;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Intent intent = getIntent();

        Instagram instagram = intent.getParcelableExtra("instagram");

        profile = findViewById(R.id.iv_profile);
        post = findViewById(R.id.iv_post);
        username = findViewById(R.id.tv_account_username);
        followers = findViewById(R.id.tv_followers);
        following = findViewById(R.id.tv_following);

        profile.setImageResource(instagram.getImage_profile());
        post.setImageResource(instagram.getImage_post());
        username.setText(instagram.getUsername());
        followers.setText(instagram.getFollowers());
        following.setText(instagram.getFollowing());

        post.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, PostActivity.class);
                intent.putExtra("instagram", instagram);
                startActivity(intent);
            }
        }));

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, StoryActivity.class);
                intent.putExtra("instagram", instagram);
                startActivity(intent);
            }
        });
    }
}