package com.example.tugas_3_lab;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter_Post extends RecyclerView.Adapter<Adapter_Post.ViewHolder> {

    private ArrayList<Instagram> instagrams;

    public Adapter_Post(ArrayList<Instagram> instagrams) {
        this.instagrams = instagrams;;
    }

    @NonNull
    @Override
    public Adapter_Post.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_post, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter_Post.ViewHolder holder, int position) {
        Instagram instagram = instagrams.get(position);

        holder.username.setText(instagram.getUsername());
        holder.caption.setText(instagram.getCaption());
        holder.image_profile.setImageResource(instagram.getImage_profile());
        holder.image_post.setImageResource(instagram.getImage_post());

        holder.image_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, StoryActivity.class);

                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });

        holder.username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.context, ProfileActivity.class);

                intent.putExtra("instagram", instagram);
                holder.context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return instagrams.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private final ImageView image_profile, image_post;
        private final TextView username, caption;
        Context context;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image_profile = itemView.findViewById(R.id.iv_profilepictures);
            image_post = itemView.findViewById(R.id.iv_post);
            username = itemView.findViewById(R.id.tv_account);
            caption = itemView.findViewById(R.id.tv_caption);
            context = itemView.getContext();
        }
    }
}
