package com.example.tugas_3_lab;

import java.util.ArrayList;

public class DataSource {

    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams(){
        ArrayList<Instagram> instagrams = new ArrayList<>();
        instagrams.add(new Instagram("feat.dino", "11/23~12/17 FOLLOW TO JAPAN", "5.9M", "13", R.drawable.profile_dino, R.drawable.post_dino, R.drawable.post_dino));
        instagrams.add(new Instagram("ho5hi_kwon", "아주Nike❤️👟", "7.7M", "57", R.drawable.profile_hoshi, R.drawable.post_hoshi, R.drawable.post_hoshi));
        instagrams.add(new Instagram("joshu_acoustic", "I went to Paris and met Rami Mekdachi the founder of Lola James Harper… A great moment to celebrate our special edition candle THE JOSHUA HONG HAN RIVER WALK with Matcha Tea, Wood and Musk scents. The Han River is a place where I go to relax and find inspiration, I hope it brings you comfort and strength in your everyday life…\n" +
                "        \n#JOSHUA #LOLAJAMESHARPER #JOSHUALOLAJAMESHARPER", "8.7M", "20", R.drawable.profile_joshua, R.drawable.post_joshua, R.drawable.post_joshua));
        instagrams.add(new Instagram("junhui_moon", "NANA TOUR～🛫", "6.3M", "16", R.drawable.profile_jun, R.drawable.post_jun, R.drawable.post_jun));
        instagrams.add(new Instagram("sound_of_coups", "우당탕탕 쿡스쿱스", "7.9M", "15", R.drawable.profile_scoups, R.drawable.post_scoups, R.drawable.post_scoups));
        instagrams.add(new Instagram("pledis_boos", "민들레\n" +
                "        \n민들레 꽃씨야\n" +
                "에쁜 봄에\n" +
                "살랑거리다 우리 또 만나\n" +
                "        \n[Credit]\n" +
                "Lyrics by 최유리, 승관\n" +
                "Composed by 최유리, 승관\n" +
                "Arranged by 최유리 @_choiyuree ,문지혁\n" +
                "Piano : 문지혁 @flexindoor\n" +
                "String : 융스트링\n" +
                "String Arrange : 권영찬 @lemon1900\n" +
                "Recorded by 정은경 @ingrid_studio\n" +
                "Mixed by 고현정 @kokosound_studio\n" +
                "Mastered by 권남우 @kwonnamwoo", "7.9M", "14", R.drawable.profile_seungkwan, R.drawable.post_seungkwan, R.drawable.post_seungkwan));
        instagrams.add(new Instagram("xuminghao_o", "새. 해. 2024🕺🏻", "8.8M", "14", R.drawable.profile_the8, R.drawable.post_the8, R.drawable.post_the8));
        instagrams.add(new Instagram("vernonline", "KENZO with VERNON\n" +
                "        \nKENZO is thrilled to announce VERNON as its first global ambassador. @Vernonline is joining the KENZO universe, teaming up with a House that shares strong links to the international entertainment scene, under the influence of Artistic Director @Nigo.\n" +
                "        \n\"I feel honored and fortunate to be KENZO’s Global Ambassador. I’m excited to explore the synergy this partnership will introduce and look forward to showcasing a new side of me to fans around the world.\" says #VERNON\n" +
                "        \n겐조의 글로벌 앰배서더로 함께하게 되어 영광입니다. 이번 파트너십이 어떤 시너지로 이어질 수 있을지 기대되고, 전 세계 팬분들께 저의 새로운 모습을 보여드릴 수 있기를 기대합니다.\n" +
                "        \n#KENZONIGO @Vernonline", "7.7M", "22", R.drawable.profile_vernon, R.drawable.post_vernon, R.drawable.post_vernon));
        instagrams.add(new Instagram("everyone_woo", "'follow' 투어 너무 감사하고 즐거웠습니다!", "8M", "15", R.drawable.profile_wonwoo, R.drawable.post_wonwoo, R.drawable.post_wonwoo));
        instagrams.add(new Instagram("woozi_universefactory", "경음악의 신\n" +
                "        \n1. 경음악의 신\n" +
                "작사 작곡\n" +
                "2. 음악의 신 (뽕짝 Remix)\n" +
                "작사 작곡\n" +
                "3. 경음악의 신 (Inst.)\n" +
                "작곡", "6.7M", "0", R.drawable.profile_woozi, R.drawable.post_woozi, R.drawable.post_woozi));
        return instagrams;
    }
}
