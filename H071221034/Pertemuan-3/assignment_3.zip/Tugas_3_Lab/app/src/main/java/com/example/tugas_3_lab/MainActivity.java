package com.example.tugas_3_lab;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rvPost = findViewById(R.id.rv_post);
        rvPost.setHasFixedSize(true);

        Adapter_Post adapter_post = new Adapter_Post(DataSource.instagrams);
        rvPost.setAdapter(adapter_post);

        RecyclerView rvStory = findViewById(R.id.rv_story);
        rvStory.setHasFixedSize(true);

        Adapter_Story adapter_story = new Adapter_Story(DataSource.instagrams);
        rvStory.setAdapter(adapter_story);
    }
}