package com.example.tugas_3_lab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StoryActivity extends AppCompatActivity {

    private ImageView profile, story;
    private TextView username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story);

        Intent intent = getIntent();

        Instagram instagram = intent.getParcelableExtra("instagram");

        profile = findViewById(R.id.iv_profile2);
        story = findViewById(R.id.iv_story);
        username = findViewById(R.id.tv_account_username2);

        profile.setImageResource(instagram.getImage_profile());
        story.setImageResource(instagram.getImage_story());
        username.setText(instagram.getUsername());

        username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StoryActivity.this, ProfileActivity.class);
                intent.putExtra("instagram", instagram);
                startActivity(intent);
            }
        });
    }
}