package com.example.tugas_4_lab;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageView iv_profile = findViewById(R.id.iv_profilepicture);
        TextView tv_name = findViewById(R.id.tv_name);
        TextView tv_username = findViewById(R.id.tv_username);

        Intent intent = getIntent();
        Instagram instagram = intent.getParcelableExtra("instagram");

        iv_profile.setImageResource(instagram.getProfile_pict());
        tv_name.setText(instagram.getName());
        tv_username.setText(instagram.getUsername());
    }
}