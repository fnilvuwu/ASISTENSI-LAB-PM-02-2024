package com.example.tugas_4_lab;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Instagram> instagrams = generateDummyInstagrams();

    private static ArrayList<Instagram> generateDummyInstagrams(){
        ArrayList<Instagram> instagrams = new ArrayList<>();
        instagrams.add(new Instagram("Lee Chan", "feat.dino", "악 넘 예쁘고 귀엽", R.drawable.profile_dino, R.drawable.post_dino));
        instagrams.add(new Instagram("Xu Minghao", "xuminghao_o", "brown and green", R.drawable.profile_the8, R.drawable.post_the8));
        instagrams.add(new Instagram("Lee Dokyeom", "dk_is_dokyeom", "요즘은 안경을 자주쓰네", R.drawable.profile_dk, R.drawable.post_dk));
        instagrams.add(new Instagram("Kwon Soonyoung", "ho5hi_kwon", "날씨너무좋다☀️", R.drawable.profile_hoshi, R.drawable.post_hoshi));
        instagrams.add(new Instagram("Kim Mingyu", "min9yu_k", "Beautiful weather in April💙", R.drawable.profile_mingyu, R.drawable.post_mingyu));
        instagrams.add(new Instagram("Wen Junhui", "junhui_moon", "🏃🏻‍♂️☁️", R.drawable.profile_jun, R.drawable.post_jun));
        instagrams.add(new Instagram("Boo Seungkwan", "pledis_boos", "Boodapest", R.drawable.profile_seungkwan, R.drawable.post_seungkwan));
        instagrams.add(new Instagram("Lee Jihoon", "woozi_universefactory", "호랑이 (Feat. Tiger JK)\n" +
                "        \n1. 호랑이 (Feat. Tiger JK)\n" +
                "작사 작곡\n", R.drawable.profile_woozi, R.drawable.post_woozi));
        instagrams.add(new Instagram("Choi Seungcheol", "sound_of_coups", "숨은 고양이 찾기", R.drawable.profile_scoups, R.drawable.post_scoups));
        instagrams.add(new Instagram("Yoon Jeonghan", "jeonghaniyoo_n", "🤍🩶", R.drawable.profile_jeonghan, R.drawable.post_jeonghan));
        return instagrams;
    }
}