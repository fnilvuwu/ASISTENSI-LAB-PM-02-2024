package com.example.tugas_4_lab;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Instagram implements Parcelable {

    private String name;
    private String username;
    private String caption;
    private int profile_pict;
    private int post_pict;
    private Uri selectedImageUri;

    public Instagram(String name, String username, String caption, int profile_pict, int post_pict) {
        this.name = name;
        this.username = username;
        this.caption = caption;
        this.profile_pict = profile_pict;
        this.post_pict = post_pict;
    }

    public Instagram(String name, String username, String caption, int profile_pict, Uri selectedImageUri) {
        this.name = name;
        this.username = username;
        this.caption = caption;
        this.profile_pict = profile_pict;
        this.selectedImageUri = selectedImageUri;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getProfile_pict() {
        return profile_pict;
    }

    public void setProfile_pict(int profile_pict) {
        this.profile_pict = profile_pict;
    }

    public int getPost_pict() {
        return post_pict;
    }

    public void setPost_pict(int post_pict) {
        this.post_pict = post_pict;
    }

    public Uri getSelectedImageUri() {
        return selectedImageUri;
    }

    public void setSelectedImageUri(Uri selectedImageUri) {
        this.selectedImageUri = selectedImageUri;
    }

    protected Instagram(Parcel in) {
        name = in.readString();
        username = in.readString();
        caption = in.readString();
        profile_pict = in.readInt();
        post_pict = in.readInt();
    }

    public static final Creator<Instagram> CREATOR = new Creator<Instagram>() {
        @Override
        public Instagram createFromParcel(Parcel in) {
            return new Instagram(in);
        }

        @Override
        public Instagram[] newArray(int size) {
            return new Instagram[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(username);
        dest.writeString(caption);
        dest.writeInt(profile_pict);
        dest.writeInt(post_pict);
    }
}
