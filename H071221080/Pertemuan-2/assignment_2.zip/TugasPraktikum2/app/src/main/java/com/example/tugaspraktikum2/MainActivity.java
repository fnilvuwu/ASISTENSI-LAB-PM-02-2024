package com.example.tugaspraktikum2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    public static Uri inpImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void handleUploadImage(View view) {
        Intent openGalleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        openGalleryIntent.setType("image/*");
        openGallery.launch(Intent.createChooser(openGalleryIntent, "Choose Your Picture"));
    }

    ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            Uri imageUri = data.getData();
                            if (imageUri != null) {
                                ImageButton imageButton = findViewById(R.id.inpImage);
                                imageButton.setImageURI(imageUri);
                                inpImageUri = imageUri;
                            }
                        }
                    }
                }
            }
    );

    public void handleSubmitProfile(View view) {
        if (inpImageUri == null) {
            Toast.makeText(this, "Please upload your image", Toast.LENGTH_SHORT).show();
            return;
        }

        EditText editTextName = findViewById(R.id.inpName);
        String inpName = editTextName.getText().toString().trim();
        if (inpName.isEmpty()) {
            editTextName.setError("Please fill in the name");
            return;
        }

        EditText editTextUsername = findViewById(R.id.inpUsername);
        String inpUsername = editTextUsername.getText().toString().trim();
        if (inpUsername.isEmpty()) {
            editTextUsername.setError("Please fill in the username");
            return;
        }

        Data data = new Data();
        data.setName(inpName);
        data.setUsername(inpUsername);
        data.setImage(inpImageUri);

        Intent toNoteActivity = new Intent(MainActivity.this, NoteActivity.class);
        toNoteActivity.putExtra(NoteActivity.PARCEL_DATA, data);

        startActivity(toNoteActivity);
    }
}