package com.example.tugaspraktikum2;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ResultActivity extends AppCompatActivity {
    public static final String PARCEL_DATA = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_result);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Data data = getIntent().getParcelableExtra(PARCEL_DATA);

        ImageView resultImage = findViewById(R.id.resultImage);
        resultImage.setImageURI(data.getImage());

        TextView resultName = findViewById(R.id.resultName);
        resultName.setText(data.getName());

        TextView resultUsername = findViewById(R.id.resultUsername);
        resultUsername.setText(data.getUsername());

        TextView resultNoteTitle = findViewById(R.id.resultNoteTitle);
        resultNoteTitle.setText(data.getNoteTitle());

        TextView resultNoteContent = findViewById(R.id.resultNoteContent);
        resultNoteContent.setText(data.getNoteContent());
    }
}