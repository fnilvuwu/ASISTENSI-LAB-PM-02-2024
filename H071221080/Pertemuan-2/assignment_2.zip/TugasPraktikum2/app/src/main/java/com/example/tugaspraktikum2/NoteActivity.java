package com.example.tugaspraktikum2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class NoteActivity extends AppCompatActivity {
    public static final String PARCEL_DATA = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void handleSaveNote(View view) {
        EditText editTextNoteTitle = findViewById(R.id.inpNoteTitle);
        String inpNoteTitle = editTextNoteTitle.getText().toString().trim();
        if (inpNoteTitle.isEmpty()) {
            editTextNoteTitle.setError("Please fill in the note's title");
            return;
        }

        EditText editTextNoteContent = findViewById(R.id.inpNoteContent);
        String inpNoteContent = editTextNoteContent.getText().toString().trim();
        if (inpNoteContent.isEmpty()) {
            editTextNoteContent.setError("Please fill in the note's content");
            return;
        }

        Data data = getIntent().getParcelableExtra(PARCEL_DATA);
        if (data != null) {
            data.setNoteTitle(inpNoteTitle);
        }
        if (data != null) {
            data.setNoteContent(inpNoteContent);
        }

        Intent toResultActivity = new Intent(NoteActivity.this, ResultActivity.class);
        toResultActivity.putExtra(ResultActivity.PARCEL_DATA, data);

        startActivity(toResultActivity);
    }
}