package com.example.tugaspraktikum3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {
    public static final String PARCEL_PROFILE = "";
    ImageView profileProfileImage, profileFeedImage;
    TextView profileUsername, profileFollowers, profileFollowing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        profileProfileImage = findViewById(R.id.profileProfileImage);
        profileUsername = findViewById(R.id.profileUsername);
        profileFollowers = findViewById(R.id.profileFollowers);
        profileFollowing = findViewById(R.id.profileFollowing);
        profileFeedImage = findViewById(R.id.profileFeedImage);

        Account account = getIntent().getParcelableExtra(PARCEL_PROFILE);
        if (account != null) {
            profileProfileImage.setImageResource(account.getProfileImage());
            profileUsername.setText(account.getUsername());
            profileFollowers.setText(account.getFollowers());
            profileFollowing.setText(account.getFollowing());
            profileFeedImage.setImageResource(account.getFeedImage());

            profileProfileImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toStoryActivity = new Intent(ProfileActivity.this, StoryActivity.class);
                    toStoryActivity.putExtra(StoryActivity.PARCEL_STORY, account);

                    startActivity(toStoryActivity);
                }
            });

            profileFeedImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toFeedDetailActivity = new Intent(ProfileActivity.this, FeedDetailActivity.class);
                    toFeedDetailActivity.putExtra(FeedDetailActivity.PARCEL_FEED_DETAIL, account);

                    startActivity(toFeedDetailActivity);
                }
            });
        }
    }
}