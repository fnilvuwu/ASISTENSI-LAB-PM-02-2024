package com.example.tugaspraktikum3;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Account> accounts = generateDummyAccounts();

    private static ArrayList<Account> generateDummyAccounts() {
        ArrayList<Account> newAccounts = new ArrayList<>();

        newAccounts.add(new Account("kokbisa", "845K", "217", R.drawable.profile_kokbisa, R.drawable.story_kokbisa, R.drawable.feed_kokbisa, R.string.feed_kokbisa));

        newAccounts.add(new Account("makassar_iinfo", "1.9M", "1", R.drawable.profile_makassarinfo, R.drawable.story_makassarinfo, R.drawable.feed_makassar_iinfo, R.string.feed_makassariinfo));

        newAccounts.add(new Account("memecomid.id", "847K", "1", R.drawable.profile_memecomicid, R.drawable.story_memecomicid, R.drawable.feed_memecomicid, R.string.feed_memecomicid));

        newAccounts.add(new Account("infipop.id", "3M", "247", R.drawable.profile_infipopid, R.drawable.story_infipopid, R.drawable.feed_infipopid, R.string.feed_infipopid));

        newAccounts.add(new Account("mpl.id.official", "6.4M", "186", R.drawable.profile_mplidofficial, R.drawable.story_mplidofficial, R.drawable.feed_mplidofficial, R.string.feed_mplidofficial));

        newAccounts.add(new Account("sosmedmakassar", "246K", "148", R.drawable.profile_sosmedmakassar, R.drawable.story_sosmedmakassar, R.drawable.feed_sosmedmakassar, R.string.feed_sosmedmakassar));

        newAccounts.add(new Account("narasinewsroom", "1.3M", "19", R.drawable.profile_narasinewsroom, R.drawable.story_narasinewsroom, R.drawable.feed_narasinewsroom, R.string.feed_narasinewsroom));

        newAccounts.add(new Account("lukananakit", "108K", "9", R.drawable.profile_lukananakit, R.drawable.story_lukananakit, R.drawable.feed_lukananakit, R.string.feed_lukananakit));

        newAccounts.add(new Account("folkative", "5.6M", "9", R.drawable.profile_folkative, R.drawable.story_folkative, R.drawable.feed_folkative, R.string.feed_folkative));

        newAccounts.add(new Account("godzillamovie", "173K", "12", R.drawable.profile_godzillamovie, R.drawable.story_godzillamovie, R.drawable.feed_godzillamovie, R.string.feed_godzillamovie));

        return newAccounts;
    }
}
