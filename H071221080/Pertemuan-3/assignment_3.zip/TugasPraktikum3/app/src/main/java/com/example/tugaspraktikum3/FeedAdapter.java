package com.example.tugaspraktikum3;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Account> accounts;

    public FeedAdapter(Context context, ArrayList<Account> accounts) {
        this.context = context;
        this.accounts = accounts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_feed, parent, false);
        return new FeedAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Account account = accounts.get(position);
        holder.setData(account);

        holder.feedProfileContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toProfileActivity = new Intent(context, ProfileActivity.class);
                toProfileActivity.putExtra(ProfileActivity.PARCEL_PROFILE, account);

                context.startActivity(toProfileActivity);
            }
        });

        holder.feedImageAndDescContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toFeedDetailActivity = new Intent(context, FeedDetailActivity.class);
                toFeedDetailActivity.putExtra(FeedDetailActivity.PARCEL_FEED_DETAIL, account);

                context.startActivity(toFeedDetailActivity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView feedUsername;
        private final ImageView feedProfileImage;
        private final LinearLayout feedProfileContainer;
        private final LinearLayout feedImageAndDescContainer;
        private final ImageView feedImage;
        private final TextView feedDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            feedUsername = itemView.findViewById(R.id.feedUsername);
            feedProfileImage = itemView.findViewById(R.id.feedProfileImage);
            feedProfileContainer = itemView.findViewById(R.id.feedProfileContainer);
            feedImageAndDescContainer = itemView.findViewById(R.id.feedImageAndDescContainer);
            feedImage = itemView.findViewById(R.id.feedImage);
            feedDesc = itemView.findViewById(R.id.feedDesc);
        }

        public void setData(Account account) {
            feedUsername.setText(account.getUsername());
            feedProfileImage.setImageResource(account.getProfileImage());
            feedImage.setImageResource(account.getFeedImage());
            feedDesc.setText(account.getFeedDesc());
        }
    }
}
