package com.example.tugaspraktikum3;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Account> accounts;

    public StoryAdapter(Context context, ArrayList<Account> accounts) {
        this.context = context;
        this.accounts = accounts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_story, parent, false);
        return new StoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Account account = accounts.get(position);
        holder.setData(account);

        holder.storyContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toStoryActivity = new Intent(context, StoryActivity.class);
                toStoryActivity.putExtra(StoryActivity.PARCEL_STORY, account);

                ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation((Activity) context);

                context.startActivity(toStoryActivity, options.toBundle());
            }
        });
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView username;
        private final ImageView profileImage;
        private final LinearLayout storyContainer;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            profileImage = itemView.findViewById(R.id.profileImage);
            storyContainer = itemView.findViewById(R.id.storyContainer);
        }

        public void setData(Account account) {
            username.setText(account.getUsername());
            profileImage.setImageResource(account.getProfileImage());
        }
    }
}
