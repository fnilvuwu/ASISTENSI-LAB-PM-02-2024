package com.example.tugaspraktikum3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FeedDetailActivity extends AppCompatActivity {
    public static final String PARCEL_FEED_DETAIL = "";

    LinearLayout feedDetailProfileContainer;
    ImageView feedDetailProfileImage, feedDetailImage;
    TextView feedDetailUsername, feedDetailDesc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_feed_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        feedDetailProfileContainer = findViewById(R.id.feedDetailProfileContainer);
        feedDetailProfileImage = findViewById(R.id.feedDetailProfileImage);
        feedDetailUsername = findViewById(R.id.feedDetailUsername);
        feedDetailImage = findViewById(R.id.feedDetailImage);
        feedDetailDesc = findViewById(R.id.feedDetailDesc);

        Account account = getIntent().getParcelableExtra(PARCEL_FEED_DETAIL);
        if (account != null) {
            feedDetailProfileImage.setImageResource(account.getProfileImage());
            feedDetailUsername.setText(account.getUsername());
            feedDetailImage.setImageResource(account.getFeedImage());
            feedDetailDesc.setText(account.getFeedDesc());

            feedDetailProfileContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toProfileActivity = new Intent(FeedDetailActivity.this, ProfileActivity.class);
                    toProfileActivity.putExtra(ProfileActivity.PARCEL_PROFILE, account);

                    startActivity(toProfileActivity);
                }
            });
        }
    }
}