package com.example.tugaspraktikum3;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Account implements Parcelable {
    private String username;
    private String followers;
    private String following;
    private int profileImage;
    private int storyImage;
    private int feedImage;
    private int feedDesc;

    public Account() {
    }

    public Account(String username, String followers, String following, int profileImage, int storyImage, int feedImage, int feedDesc) {
        this.username = username;
        this.followers = followers;
        this.following = following;
        this.profileImage = profileImage;
        this.storyImage = storyImage;
        this.feedImage = feedImage;
        this.feedDesc = feedDesc;
    }

    protected Account(Parcel in) {
        username = in.readString();
        followers = in.readString();
        following = in.readString();
        profileImage = in.readInt();
        storyImage = in.readInt();
        feedImage = in.readInt();
        feedDesc = in.readInt();
    }

    public static final Creator<Account> CREATOR = new Creator<Account>() {
        @Override
        public Account createFromParcel(Parcel in) {
            return new Account(in);
        }

        @Override
        public Account[] newArray(int size) {
            return new Account[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(username);
        dest.writeString(followers);
        dest.writeString(following);
        dest.writeInt(profileImage);
        dest.writeInt(storyImage);
        dest.writeInt(feedImage);
        dest.writeInt(feedDesc);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFollowers() {
        return followers;
    }

    public void setFollowers(String followers) {
        this.followers = followers;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public int getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(int profileImage) {
        this.profileImage = profileImage;
    }

    public int getStoryImage() {
        return storyImage;
    }

    public void setStoryImage(int storyImage) {
        this.storyImage = storyImage;
    }

    public int getFeedImage() {
        return feedImage;
    }

    public void setFeedImage(int feedImage) {
        this.feedImage = feedImage;
    }

    public int getFeedDesc() {
        return feedDesc;
    }

    public void setFeedDesc(int feedDesc) {
        this.feedDesc = feedDesc;
    }
}
