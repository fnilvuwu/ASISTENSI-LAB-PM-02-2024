package com.example.tugaspraktikum3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StoryActivity extends AppCompatActivity {
    public static final String PARCEL_STORY = "";

    LinearLayout storyImage, storyProfileContainer;
    TextView storyUsername;
    ImageView storyProfileImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_story);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        storyImage = findViewById(R.id.storyImage);
        storyProfileContainer = findViewById(R.id.storyProfileContainer);
        storyUsername = findViewById(R.id.storyUsername);
        storyProfileImage = findViewById(R.id.storyProfileImage);

        Account account = getIntent().getParcelableExtra(PARCEL_STORY);
        if (account != null) {
            storyImage.setBackgroundResource(account.getStoryImage());
            storyUsername.setText(account.getUsername());
            storyProfileImage.setImageResource(account.getProfileImage());

            storyProfileContainer.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent toProfileActivity = new Intent(StoryActivity.this, ProfileActivity.class);
                    toProfileActivity.putExtra(ProfileActivity.PARCEL_PROFILE, account);

                    startActivity(toProfileActivity);
                }
            });
        }
    }
}