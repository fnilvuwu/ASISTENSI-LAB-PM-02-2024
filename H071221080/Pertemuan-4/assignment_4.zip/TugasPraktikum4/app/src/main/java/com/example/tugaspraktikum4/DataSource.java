package com.example.tugaspraktikum4;

import java.util.ArrayList;

public class DataSource {
    public static ArrayList<Account> accounts = generateDummyAccounts();

    private static ArrayList<Account> generateDummyAccounts() {
        ArrayList<Account> newAccounts = new ArrayList<>();

        newAccounts.add(new Account("Kok Bisa", "kokbisa", R.drawable.profile_kokbisa, R.string.feed_kokbisa, R.drawable.feed_kokbisa));

        newAccounts.add(new Account("Makassar Info", "makassar_iinfo", R.drawable.profile_makassarinfo, R.string.feed_makassariinfo, R.drawable.feed_makassar_iinfo));

        newAccounts.add(new Account("Lu kan Anak IT", "lukananakit", R.drawable.profile_lukananakit, R.string.feed_lukananakit, R.drawable.feed_lukananakit));

        newAccounts.add(new Account("Godzilla Movie", "godzillamovie", R.drawable.profile_godzillamovie, R.string.feed_godzillamovie, R.drawable.feed_godzillamovie));

        newAccounts.add(new Account("MPL ID Official", "mpl.id.official", R.drawable.profile_mplidofficial, R.string.feed_mplidofficial, R.drawable.feed_mplidofficial));

        return newAccounts;
    }
}
