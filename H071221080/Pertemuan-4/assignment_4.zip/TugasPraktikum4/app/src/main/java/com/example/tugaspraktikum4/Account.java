package com.example.tugaspraktikum4;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Account implements Parcelable {
    private String name;
    private String username;
    private int profileImage;
    private int feedCaption;
    private int feedImage;
    private String addFeedCaption;
    private Uri addFeedImage;

    public Account(String name, String username, int profileImage, int feedCaption, int feedImage) {
        this.name = name;
        this.username = username;
        this.profileImage = profileImage;
        this.feedCaption = feedCaption;
        this.feedImage = feedImage;
    }

    public Account(String name, String username, int profileImage, String addFeedCaption, Uri addFeedImage) {
        this.name = name;
        this.username = username;
        this.profileImage = profileImage;
        this.addFeedCaption = addFeedCaption;
        this.addFeedImage = addFeedImage;
    }

    protected Account(Parcel in) {
        name = in.readString();
        username = in.readString();
        profileImage = in.readInt();
        feedCaption = in.readInt();
        feedImage = in.readInt();
        addFeedCaption = in.readString();
        addFeedImage = in.readParcelable(Uri.class.getClassLoader());
    }

    public static final Creator<Account> CREATOR = new Creator<Account>() {
        @Override
        public Account createFromParcel(Parcel in) {
            return new Account(in);
        }

        @Override
        public Account[] newArray(int size) {
            return new Account[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(username);
        dest.writeInt(profileImage);
        dest.writeInt(feedCaption);
        dest.writeInt(feedImage);
        dest.writeString(addFeedCaption);
        dest.writeParcelable(addFeedImage, flags);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(int profileImage) {
        this.profileImage = profileImage;
    }

    public int getFeedCaption() {
        return feedCaption;
    }

    public void setFeedCaption(int feedCaption) {
        this.feedCaption = feedCaption;
    }

    public int getFeedImage() {
        return feedImage;
    }

    public void setFeedImage(int feedImage) {
        this.feedImage = feedImage;
    }

    public String getAddFeedCaption() {
        return addFeedCaption;
    }

    public void setAddFeedCaption(String addFeedCaption) {
        this.addFeedCaption = addFeedCaption;
    }

    public Uri getAddFeedImage() {
        return addFeedImage;
    }

    public void setAddFeedImage(Uri addFeedImage) {
        this.addFeedImage = addFeedImage;
    }
}
