package com.example.tugaspraktikum4.fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.tugaspraktikum4.R;

public class ConfirmationDeleteFeedFragment extends DialogFragment {
    private Button buttonDeleteFeedYes, buttonDeleteFeedNo;
    private OnDeleteFeedConfirmedListener listener;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_confirmation_delete_feed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        buttonDeleteFeedYes = view.findViewById(R.id.buttonDeleteFeedYes);
        buttonDeleteFeedNo = view.findViewById(R.id.buttonDeleteFeedNo);

        buttonDeleteFeedYes.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteFeedConfirmed();
            }
            getDialog().dismiss();
        });

        buttonDeleteFeedNo.setOnClickListener(v -> {
            getDialog().cancel();
        });
    }

    public interface OnDeleteFeedConfirmedListener {
        void onDeleteFeedConfirmed();
    }

    public void setOnDeleteFeedConfirmedListener(OnDeleteFeedConfirmedListener listener) {
        this.listener = listener;
    }

}