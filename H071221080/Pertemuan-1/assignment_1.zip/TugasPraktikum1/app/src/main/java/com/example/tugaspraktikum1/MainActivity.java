package com.example.tugaspraktikum1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void addTextElement(View view) {
        EditText editText = findViewById(R.id.inputText);
        String inputText = editText.getText().toString().trim();

        if (!inputText.isEmpty()) {
            TextView textView = new TextView(this);
            textView.setText(inputText);

//            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
//                    LinearLayout.LayoutParams.MATCH_PARENT,
//                    LinearLayout.LayoutParams.WRAP_CONTENT
//            );
//            layoutParams.setMargins(0, 0, 0, 20);
//            textView.setLayoutParams(layoutParams);

            LinearLayout newTextLayout = findViewById(R.id.newTextLayout);
            newTextLayout.addView(textView);

            editText.setText("");
        }
    }
}
