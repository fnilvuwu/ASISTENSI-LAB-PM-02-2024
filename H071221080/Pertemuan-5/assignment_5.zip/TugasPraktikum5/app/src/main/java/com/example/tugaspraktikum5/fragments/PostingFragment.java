package com.example.tugaspraktikum5.fragments;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.tugaspraktikum5.Account;
import com.example.tugaspraktikum5.DataSource;
import com.example.tugaspraktikum5.FeedAdapter;
import com.example.tugaspraktikum5.R;

public class PostingFragment extends Fragment {
    private EditText inpFeedCaption;
    private ImageButton inpFeedImage;
    public static Uri inpFeedImageUri;
    private Button submitPostFeedButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_posting, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        inpFeedCaption = view.findViewById(R.id.inpFeedCaption);
        inpFeedImage = view.findViewById(R.id.inpFeedImage);
        submitPostFeedButton = view.findViewById(R.id.submitPostFeedButton);

        inpFeedImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openGalleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
                openGalleryIntent.setType("image/*");
                openGallery.launch(Intent.createChooser(openGalleryIntent, "Choose Your Picture"));
            }
        });

        submitPostFeedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inpFeedImageUri == null) {
                    Toast.makeText(getActivity(), "Please upload your image", Toast.LENGTH_SHORT).show();
                    return;
                }

                String inpFeedCaptionValue = inpFeedCaption.getText().toString().trim();
                if (inpFeedCaptionValue.isEmpty()) {
                    inpFeedCaption.setError("Please fill in the name");
                    return;
                }

                Account account = new Account("kokbisa", "Kok Bisa", R.drawable.profile_kokbisa, inpFeedCaptionValue, inpFeedImageUri);

                FeedAdapter feedAdapter = new FeedAdapter(getActivity(), DataSource.accounts);
                feedAdapter.addPost(account);

                HomeFragment categoryFragment = new HomeFragment();
                FragmentManager fragmentManager = getParentFragmentManager();
                fragmentManager
                        .beginTransaction()
                        .replace(R.id.frameContainer, categoryFragment)
                        .addToBackStack(null)
                        .commit();

            }
        });
    }

    ActivityResultLauncher<Intent> openGallery = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null) {
                            Uri imageUri = data.getData();
                            if (imageUri != null) {
                                inpFeedImage.setImageURI(imageUri);
                                inpFeedImageUri = imageUri;
                            }
                        }
                    }
                }
            }
    );
}