package com.example.tugaspraktikum5;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tugaspraktikum5.fragments.ConfirmationDeleteFeedFragment;

import java.util.ArrayList;

public class FeedAdapter extends RecyclerView.Adapter<FeedAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Account> accounts;

    public FeedAdapter(Context context, ArrayList<Account> accounts) {
        this.context = context;
        this.accounts = accounts;
    }

    public void addPost(Account account) {
        accounts.add(0, account);
        notifyItemInserted(accounts.size() - 1);
    }

    public void removePost(int position) {
        if (position >= 0 && position < accounts.size()) {
            accounts.remove(position);
            notifyItemRemoved(position);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_feed, parent, false);
        return new FeedAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Account account = accounts.get(position);
        holder.setData(account);

        holder.feedProfileContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toProfileActivity = new Intent(context, ProfileActivity.class);
                toProfileActivity.putExtra(ProfileActivity.PARCEL_PROFILE, account);

                context.startActivity(toProfileActivity);
            }
        });

        holder.feedDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConfirmationDeleteFeedFragment confirmationDeleteFeedFragment = new ConfirmationDeleteFeedFragment();
                FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();
                confirmationDeleteFeedFragment.show(fragmentManager, ConfirmationDeleteFeedFragment.class.getSimpleName());

                confirmationDeleteFeedFragment.setOnDeleteFeedConfirmedListener(() -> {
                    removePost(position);
                });

            }
        });
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private final LinearLayout feedProfileContainer;
        private final ImageView feedProfileImage;
        private final TextView feedProfileName;
        private final TextView feedProfileUsername;
        private final TextView feedCaption;
        private final ImageView feedImage;
        private final ImageView feedDeleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            feedProfileContainer = itemView.findViewById(R.id.feedProfileContainer);
            feedProfileImage = itemView.findViewById(R.id.feedProfileImage);
            feedProfileName = itemView.findViewById(R.id.feedProfileName);
            feedProfileUsername = itemView.findViewById(R.id.feedProfileUsername);
            feedCaption = itemView.findViewById(R.id.feedCaption);
            feedImage = itemView.findViewById(R.id.feedImage);
            feedDeleteButton = itemView.findViewById(R.id.feedDeleteButton);
        }

        public void setData(Account account) {
            feedProfileImage.setImageResource(account.getProfileImage());
            feedProfileName.setText(account.getName());
            feedProfileUsername.setText(account.getUsername());

            // Check the types of feedCaption and feedImage to handle both types
            if (account.getAddFeedCaption() != null && account.getAddFeedImage() != null) {
                // If there are uploaded caption and image from user
                feedCaption.setText(account.getAddFeedCaption());
                feedImage.setImageURI(account.getAddFeedImage());
            } else {
                // Otherwise, use static caption and image from resources
                feedCaption.setText(context.getString(account.getFeedCaption()));
                feedImage.setImageResource(account.getFeedImage());
            }
        }
    }
}
