package com.example.tugaspraktikum5;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileActivity extends AppCompatActivity {
    public static final String PARCEL_PROFILE = "";
    private ImageView profileProfileImage;
    private TextView profileName, profileUsername;
    private View profileLoadingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profileProfileImage = findViewById(R.id.profileProfileImage);
        profileName = findViewById(R.id.profileName);
        profileUsername = findViewById(R.id.profileUsername);
        profileLoadingView = findViewById(R.id.profileLoading);

        Handler handler = new Handler(Looper.getMainLooper());
        ExecutorService executor = Executors.newSingleThreadExecutor();

        profileLoadingView.setVisibility(View.VISIBLE);
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(1000);

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            profileLoadingView.setVisibility(View.GONE);
                        }
                    });
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Account account = getIntent().getParcelableExtra(PARCEL_PROFILE);
        if (account != null) {
            profileProfileImage.setImageResource(account.getProfileImage());
            profileName.setText(account.getName());
            profileUsername.setText(account.getUsername());
        }
    }
}
