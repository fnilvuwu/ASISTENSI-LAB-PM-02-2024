package com.example.tugaspraktikum5;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SearchUserAdapter extends RecyclerView.Adapter<SearchUserAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Account> accounts;

    public SearchUserAdapter(Context context, ArrayList<Account> accounts) {
        this.context = context;
        this.accounts = accounts;
    }

    public void searchUser(String query) {
        if (query.isEmpty()) {
            accounts.clear();
            notifyDataSetChanged();
            return;
        }

        ArrayList<Account> filteredList = new ArrayList<>();

        for (Account account : DataSource.accounts) {
            if (account.getUsername().toLowerCase().contains(query.toLowerCase()) ||
                    account.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(account);
            }
        }

        accounts.clear();
        accounts.addAll(filteredList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_profile, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Account account = accounts.get(position);
        holder.setData(account);

        holder.searchUserContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toProfileActivity = new Intent(context, ProfileActivity.class);
                toProfileActivity.putExtra(ProfileActivity.PARCEL_PROFILE, account);

                context.startActivity(toProfileActivity);
            }
        });
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final LinearLayout searchUserContainer;
        private final ImageView searchUserProfileImage;
        private final TextView searchUserName;
        private final TextView searchUserUsername;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            searchUserContainer = itemView.findViewById(R.id.searchUserContainer);
            searchUserProfileImage = itemView.findViewById(R.id.searchUserProfileImage);
            searchUserName = itemView.findViewById(R.id.searchUserName);
            searchUserUsername = itemView.findViewById(R.id.searchUserUsername);
        }

        public void setData(Account user) {
            searchUserProfileImage.setImageResource(user.getProfileImage());
            searchUserName.setText(user.getName());
            searchUserUsername.setText(user.getUsername());
        }
    }
}
