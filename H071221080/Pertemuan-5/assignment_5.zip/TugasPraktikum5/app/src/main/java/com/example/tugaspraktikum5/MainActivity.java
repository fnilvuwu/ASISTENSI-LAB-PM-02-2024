package com.example.tugaspraktikum5;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.tugaspraktikum5.fragments.HomeFragment;
import com.example.tugaspraktikum5.fragments.PostingFragment;
import com.example.tugaspraktikum5.fragments.ProfileFragment;
import com.example.tugaspraktikum5.fragments.SearchFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private MenuItem navHome;
    private MenuItem navPosting;
    private MenuItem navProfile;
    private BottomNavigationView bottomNavigationView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottomNavigation);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                Fragment selectedFragment = null;

                if (item.getItemId() == R.id.nav_home) {
                    selectedFragment = new HomeFragment();
                } else if (item.getItemId() == R.id.nav_posting) {
                    selectedFragment = new PostingFragment();
                } else if (item.getItemId() == R.id.nav_profile) {
                    selectedFragment = new ProfileFragment();
                } else if (item.getItemId() == R.id.nav_search) {
                    selectedFragment = new SearchFragment();
                }

                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.frameContainer, selectedFragment)
                            .addToBackStack(null)
                            .commit();
                }

                return true;
            }
        });

        // Set initial fragment as HomeFragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frameContainer, new HomeFragment())
                .commit();
    }
}
