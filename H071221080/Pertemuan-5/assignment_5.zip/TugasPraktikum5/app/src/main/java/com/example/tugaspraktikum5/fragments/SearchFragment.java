package com.example.tugaspraktikum5.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import com.example.tugaspraktikum5.R;
import com.example.tugaspraktikum5.SearchUserAdapter;

import java.util.ArrayList;

public class SearchFragment extends Fragment {
    private EditText searchUserInput;
    private RecyclerView rvSearchUsers;
    private SearchUserAdapter searchUserAdapter;
    private View searchUserLoadingView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        searchUserInput = view.findViewById(R.id.searchUserInput);
        rvSearchUsers = view.findViewById(R.id.rvSearchUsers);
        searchUserLoadingView = view.findViewById(R.id.searchUserLoading);

        searchUserAdapter = new SearchUserAdapter(getContext(), new ArrayList<>());
        rvSearchUsers.setAdapter(searchUserAdapter);

        Handler handler = new Handler(Looper.getMainLooper());

        searchUserLoadingView.setVisibility(View.GONE);
        searchUserInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchUserLoadingView.setVisibility(View.VISIBLE);
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        searchUserAdapter.searchUser(s.toString());
                        searchUserLoadingView.setVisibility(View.GONE);
                    }
                }, 500);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }
}