package com.example.tugaspraktikum8;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tugaspraktikum8.config.DbConfig;
import com.google.android.material.textfield.TextInputLayout;

public class AddNoteActivity extends AppCompatActivity {

    ImageButton ibBack;
    Button btnSubmit;
    TextInputLayout tilTitle;
    TextInputLayout tilDescription;
    DbConfig dbConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbConfig = new DbConfig(this);

        btnSubmit = findViewById(R.id.btn_submit);
        tilTitle = findViewById(R.id.titleInput);
        tilDescription = findViewById(R.id.descInput);

        ibBack = findViewById(R.id.btn_back);

        ibBack.setOnClickListener(v ->
                showExitConfirmationDialog());

        btnSubmit.setOnClickListener(v -> {
            String judul = tilTitle.getEditText().getText().toString().trim();
            String deskripsi = tilDescription.getEditText().getText().toString().trim();

            if (judul.isEmpty()) {
                tilTitle.setError("Please enter your Judul");
            } else {
                dbConfig.insertNote(judul, deskripsi);
                Toast.makeText(AddNoteActivity.this, "Note added successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    private void showExitConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Cancel")
                .setMessage("Apakah anda ingin membatalkan penambahan pada form?")
                .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                .setPositiveButton("Yes", (dialog, which) -> {
                    dialog.dismiss();
                    super.onBackPressed();
                })
                .create()
                .show();
    }

    @Override
    public void onBackPressed() {
        showExitConfirmationDialog();
    }
}