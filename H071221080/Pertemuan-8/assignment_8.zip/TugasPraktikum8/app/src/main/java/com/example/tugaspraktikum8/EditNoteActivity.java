package com.example.tugaspraktikum8;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tugaspraktikum8.config.DbConfig;

public class EditNoteActivity extends AppCompatActivity {

    private EditText etUpdateTitle;
    private EditText etUpdateDescription;
    private DbConfig dbConfig;
    private int noteId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_note);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbConfig = new DbConfig(this);

        etUpdateTitle = findViewById(R.id.et_upjudul);
        etUpdateDescription = findViewById(R.id.et_updesc);
        Button btnUpdate = findViewById(R.id.btn_update);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("note_id")) {
            noteId = intent.getIntExtra("note_id", -1);
            loadRecordData(noteId);
        }


        findViewById(R.id.btn_backk).setOnClickListener(v -> showCancelConfirmationDialog());

        findViewById(R.id.btn_delete).setOnClickListener(v -> {
            dbConfig.deleteNote(noteId);
            showDeleteConfirmationDialog();
        });


        btnUpdate.setOnClickListener(v -> {
            String judul = etUpdateTitle.getText().toString();
            String deskripsi = etUpdateDescription.getText().toString();

            if (!judul.isEmpty() && !deskripsi.isEmpty()) {
                dbConfig.updateNote(noteId, judul, deskripsi);
                finish(); // Close this activity
            } else {
                if (judul.isEmpty()) {
                    etUpdateTitle.setError("Judul tidak boleh kosong");
                }
                if (deskripsi.isEmpty()) {
                    etUpdateDescription.setError("Deskripsi tidak boleh kosong");
                }
            }
        });
    }

    private void loadRecordData(int id) {
        Cursor cursor = dbConfig.getReadableDatabase().rawQuery("SELECT * FROM " + dbConfig.getTableName() + " WHERE " + dbConfig.getColumnId() + " = ?", new String[]{String.valueOf(id)});
        if (cursor != null && cursor.moveToFirst()) {
            etUpdateTitle.setText(cursor.getString(cursor.getColumnIndexOrThrow(dbConfig.getColumnTitle())));
            etUpdateDescription.setText(cursor.getString(cursor.getColumnIndexOrThrow(dbConfig.getColumnDescription())));
            cursor.close();
        }
    }

    private void showDeleteConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Hapus Note");
        builder.setMessage("Apakah anda yakin ingin menghapus item ini?");
        builder.setPositiveButton("Ya", (dialog, which) -> {
            dbConfig.deleteNote(noteId);
            finish();
        });
        builder.setNegativeButton("Tidak", (dialog, which) ->
                dialog.dismiss());
        builder.create().show();
    }

    private void showCancelConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Batal");
        builder.setMessage("Apakah anda ingin membatalkan perubahan pada form?");

        builder.setPositiveButton("Ya", (dialog, which) -> {
            Intent intent = new Intent(EditNoteActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
        builder.setNegativeButton("Tidak", (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

    @Override
    public void onBackPressed() {
        showCancelConfirmationDialog();
    }

}