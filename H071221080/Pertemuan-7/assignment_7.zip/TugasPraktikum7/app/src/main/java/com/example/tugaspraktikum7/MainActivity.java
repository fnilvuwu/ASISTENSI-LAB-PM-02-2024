package com.example.tugaspraktikum7;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText login_et_nim, login_et_password;
    Button login_btn_submit, login_btn_register;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        login_et_nim = findViewById(R.id.login_et_nim);
        login_et_password = findViewById(R.id.login_et_password);
        login_btn_submit = findViewById(R.id.login_btn_submit);
        login_btn_register = findViewById(R.id.login_btn_register);

        checkLoginStatus();

        login_btn_submit.setOnClickListener(view -> {
            String inpNim = login_et_nim.getText().toString().trim();
            String inpPassword = login_et_password.getText().toString().trim();

            if (!inpNim.isEmpty() && !inpPassword.isEmpty()) {
//                Validate Login
                preferences = getSharedPreferences("user_pref", MODE_PRIVATE);
                String storedNim = preferences.getString("nim", "");
                String storedPassword = preferences.getString("password", "");
                boolean isValidLogin = inpNim.equals(storedNim) && inpPassword.equals(storedPassword);

                if (isValidLogin) {
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putBoolean("is_logged_in", true);
                    editor.apply();

                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Please enter NIM and password", Toast.LENGTH_SHORT).show();
            }
        });

        login_btn_register.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        checkThemeApp();
    }

    private void checkLoginStatus() {
        preferences = this.getSharedPreferences("user_pref", MODE_PRIVATE);
        boolean isLoggedIn = preferences.getBoolean("is_logged_in", false);
        if (isLoggedIn) {
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void checkThemeApp() {
        preferences = getSharedPreferences("theme_pref", MODE_PRIVATE);
        boolean isDarkTheme = preferences.getBoolean("is_dark_theme", false);
        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}