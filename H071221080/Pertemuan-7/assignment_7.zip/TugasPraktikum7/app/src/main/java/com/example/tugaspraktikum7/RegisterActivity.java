package com.example.tugaspraktikum7;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {
    EditText register_et_nim, register_et_password;
    Button register_btn_submit;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        register_et_nim = findViewById(R.id.register_et_nim);
        register_et_password = findViewById(R.id.register_et_password);
        register_btn_submit = findViewById(R.id.register_btn_submit);

        register_btn_submit.setOnClickListener(view -> {
            String inpNim = String.valueOf(register_et_nim.getText());
            String inpPassword = String.valueOf(register_et_password.getText());

            if (!inpNim.isEmpty() && !inpPassword.isEmpty()) {
                preferences = getSharedPreferences("user_pref", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.clear();
//                editor.apply();

                editor.putString("nim", inpNim);
                editor.putString("password", inpPassword);
                editor.apply();

                Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(RegisterActivity.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
            }
        });

        checkThemeApp();
    }

    private void checkThemeApp() {
        preferences = getSharedPreferences("theme_pref", MODE_PRIVATE);
        boolean isDarkTheme = preferences.getBoolean("is_dark_theme", false);
        if (isDarkTheme) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}